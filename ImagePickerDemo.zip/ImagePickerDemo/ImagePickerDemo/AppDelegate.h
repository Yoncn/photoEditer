//
//  AppDelegate.h
//  ImagePickerDemo
//
//  Created by yoncn on 2018/3/27.
//  Copyright © 2018年 yoncn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

