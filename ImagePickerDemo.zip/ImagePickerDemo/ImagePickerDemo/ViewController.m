//
//  ViewController.m
//  ImagePickerDemo
//
//  Created by yoncn on 2018/3/27.
//  Copyright © 2018年 yoncn. All rights reserved.
//

#import "ViewController.h"
#import <Photos/Photos.h>
#import "RCImagePickerViewController.h"

@interface ViewController ()<RCImagePickerViewControllerDelegate>
@property (strong, nonatomic) IBOutlet UIImageView *resultImage;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.resultImage.contentMode = UIViewContentModeScaleAspectFit;
}

- (IBAction)takePhotoAndVideoAction:(id)sender {
    [self takePhotoOnViewController:self imagePickerControllerType:ImagePickerTypeVideoAndImageAndAlbum];
}

- (void)takePhotoOnViewController:(UIViewController *)viewController imagePickerControllerType:(ImagePickerType)type {
    AVAuthorizationStatus videoAuthStatus = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
    if (videoAuthStatus == AVAuthorizationStatusRestricted || videoAuthStatus == AVAuthorizationStatusDenied) {
        [self alertViewShowWithTitle:@"have no access to use your camera" message:nil];
    } else if (videoAuthStatus == AVAuthorizationStatusNotDetermined) {
        [AVCaptureDevice requestAccessForMediaType:AVMediaTypeVideo completionHandler:^(BOOL granted) {
            if (granted) {
                dispatch_sync(dispatch_get_main_queue(), ^{
                    [self takePhotoOnViewController:viewController imagePickerControllerType:type];
                });
            }
        }];
    } else if (videoAuthStatus == AVAuthorizationStatusAuthorized) {
        AVAuthorizationStatus audioAuthStatus = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeAudio];
        if (audioAuthStatus == AVAuthorizationStatusRestricted || audioAuthStatus == AVAuthorizationStatusDenied) {
            [self alertViewShowWithTitle:@"have no access to use your microphone" message:nil];
        } else if (audioAuthStatus == AVAuthorizationStatusNotDetermined) {
            [AVCaptureDevice requestAccessForMediaType:AVMediaTypeAudio completionHandler:^(BOOL granted) {
                if (granted) {
                    dispatch_sync(dispatch_get_main_queue(), ^{
                        [self takePhotoOnViewController:viewController imagePickerControllerType:type];
                    });
                }
            }];
        } else if (audioAuthStatus == AVAuthorizationStatusAuthorized) {
            PHAuthorizationStatus photoAuthStatus = [PHPhotoLibrary authorizationStatus];
            if (photoAuthStatus == PHAuthorizationStatusRestricted || photoAuthStatus == PHAuthorizationStatusDenied) {
                [self alertViewShowWithTitle:@"have no access to use your album" message:nil];
            } else if (photoAuthStatus == PHAuthorizationStatusNotDetermined) {
                [PHPhotoLibrary requestAuthorization:^(PHAuthorizationStatus status) {
                    dispatch_sync(dispatch_get_main_queue(), ^{
                        [self takePhotoOnViewController:viewController imagePickerControllerType:type];
                    });
                }];
            } else if (photoAuthStatus == PHAuthorizationStatusAuthorized) {
                [self pushImagePickerControllerOnViewController:viewController imagePickerControllerType:type];
            }
        }
    }
}

- (void)pushImagePickerControllerOnViewController:(UIViewController *)viewController imagePickerControllerType:(ImagePickerType)type {
    RCImagePickerViewController *imagePicker = [[RCImagePickerViewController alloc] init];
    imagePicker.delegate = self;
    imagePicker.type = type;
    UINavigationController *navigationVC = [[UINavigationController alloc] initWithRootViewController:imagePicker];
    [viewController presentViewController:navigationVC animated:YES completion:nil];
    return;
}

- (void)RCImagepickerDidFinishShotViewController:(RCImagePickerViewController *)viewController andVideoUrl:(NSURL *)fileURL image:(UIImage *)systemImage {
    if (systemImage) {
        NSLog(@"take a photo, image:%@",systemImage);
        self.resultImage.image = systemImage;
    } else if (fileURL) {
        NSLog(@"take a video, fileUrl:%@",fileURL.absoluteString);
    }
    [viewController dismissViewControllerAnimated:YES completion:nil];
}

- (void)RCImagepickerDidTapChoosePhotoOrVideoFromAlbumOnViewController:(RCImagePickerViewController *)viewController {
    NSLog(@"open album");
}

- (void)alertViewShowWithTitle:(NSString *)title message:(NSString *)message {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:message delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
    [alert show];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
