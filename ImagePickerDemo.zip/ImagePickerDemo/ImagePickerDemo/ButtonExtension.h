//
//  ButtonExtension.h
//  demo
//
//  Created by yoncn on 2017/7/17.
//  Copyright © 2017年 yoncn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ButtonExtension : UIButton

@end
