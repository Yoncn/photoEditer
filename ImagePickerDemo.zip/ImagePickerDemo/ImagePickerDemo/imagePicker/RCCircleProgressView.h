//
//  RCCircleProgressView.h
//  demo
//
//  Created by yoncn on 2018/3/6.
//  Copyright © 2018年 yoncn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RCCircleProgressView : UIView

@property(assign, nonatomic) CGFloat value;

- (instancetype)initWithFrame:(CGRect)frame defaultColor:(UIColor *)defalutColor progressColor:(UIColor *)progressColor lineWidth:(CGFloat)lineWidth;
- (void)changeCircleScalePercent:(CGFloat)newScale;
@end
