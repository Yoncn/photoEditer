//
//  RCImagePickerViewController.h
//  demo
//
//  Created by yoncn on 2018/3/6.
//  Copyright © 2018年 yoncn. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum {
    ImagePickerTypeImage,//only take photo
    ImagePickerTypeVideoAndImage, //take photo and video
    ImagePickerTypeVideoAndImageAndAlbum //take photo and video and can choose photo from album
}ImagePickerType;

@class RCImagePickerViewController;
@protocol RCImagePickerViewControllerDelegate <NSObject>
- (void)RCImagepickerDidFinishShotViewController:(RCImagePickerViewController *)viewController andVideoUrl:(NSURL *)videoUrl image:(UIImage *)image;
- (void)RCImagepickerDidTapChoosePhotoOrVideoFromAlbumOnViewController:(RCImagePickerViewController *)viewController;
@end

@interface RCImagePickerViewController : UIViewController
@property (nonatomic, assign) ImagePickerType type;
@property (nonatomic, assign) id<RCImagePickerViewControllerDelegate> delegate;
@end
