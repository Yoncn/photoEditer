//
//  RCCircleProgressView.m
//  demo
//
//  Created by yoncn on 2018/3/6.
//  Copyright © 2018年 yoncn. All rights reserved.
//

#import "RCCircleProgressView.h"

@interface RCCircleProgressView()
@property(strong, nonatomic) CAShapeLayer *shapeLayer;
@property(strong, nonatomic) CAShapeLayer *bgLayer;
@property(strong, nonatomic) CAShapeLayer *borderLayer;
@end

@implementation RCCircleProgressView

- (instancetype)initWithFrame:(CGRect)frame defaultColor:(UIColor *)defalutColor progressColor:(UIColor *)progressColor lineWidth:(CGFloat)lineWidth {
    self = [super initWithFrame:frame];
    if (self) {
        UIBezierPath *path = [UIBezierPath bezierPathWithOvalInRect:self.bounds];
        
        _borderLayer = [CAShapeLayer layer];
        _borderLayer.frame = self.bounds;
        _borderLayer.fillColor = [UIColor clearColor].CGColor;
        _borderLayer.lineWidth = lineWidth + 0.1;
        _borderLayer.strokeColor = [[UIColor blackColor] colorWithAlphaComponent:0.2].CGColor;
        _borderLayer.strokeStart = 0.f;
        _borderLayer.strokeEnd = 1.f;
        _borderLayer.path = path.CGPath;
        [self.layer addSublayer:_borderLayer];
        
        _bgLayer = [CAShapeLayer layer];
        _bgLayer.frame = self.bounds;
        _bgLayer.fillColor = [UIColor clearColor].CGColor;
        _bgLayer.lineWidth = lineWidth;
        _bgLayer.strokeColor = defalutColor.CGColor;
        _bgLayer.strokeStart = 0.f;
        _bgLayer.strokeEnd = 1.f;
        _bgLayer.path = path.CGPath;
        [self.layer addSublayer:_bgLayer];
        
        _shapeLayer = [CAShapeLayer layer];
        _shapeLayer.frame = self.bounds;
        _shapeLayer.fillColor = [UIColor clearColor].CGColor;
        _shapeLayer.lineWidth = lineWidth;
        _shapeLayer.lineCap = kCALineCapButt;
        _shapeLayer.strokeColor = progressColor.CGColor;
        _shapeLayer.strokeStart = 0.f;
        _shapeLayer.strokeEnd = 0.f;
        _shapeLayer.path = path.CGPath;
        [self.layer addSublayer:_shapeLayer];
        
        self.transform = CGAffineTransformRotate(CGAffineTransformIdentity, -M_PI/2);
    }
    return self;
}

@synthesize value = _value;
- (void)setValue:(CGFloat)value {
    _value = value;
    _shapeLayer.strokeEnd = value;
}

- (CGFloat)value {
    return _value;
}

- (void)changeCircleScalePercent:(CGFloat)newScale {
    CABasicAnimation *pulseAnimation = [CABasicAnimation animationWithKeyPath:@"transform.scale"];
    pulseAnimation.duration = 0.29;
    pulseAnimation.toValue = [NSNumber numberWithFloat:newScale];
    pulseAnimation.fillMode = kCAFillModeForwards;
    pulseAnimation.removedOnCompletion = NO;
    [_bgLayer addAnimation:pulseAnimation forKey:@"transform.scale"];
    [_shapeLayer addAnimation:pulseAnimation forKey:@"transform.scale"];
    [_borderLayer addAnimation:pulseAnimation forKey:@"transform.scale"];
}


@end
