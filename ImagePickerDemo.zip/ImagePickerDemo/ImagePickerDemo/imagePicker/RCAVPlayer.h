//
//  RCAVPlayer.h
//  demo
//
//  Created by yoncn on 2018/3/20.
//  Copyright © 2018年 yoncn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RCAVPlayer : UIView
- (instancetype)initWithFrame:(CGRect)frame withShowInView:(UIView *)backgroundView;

@property (copy, nonatomic) NSURL *videoUrl;
- (void)refreshPlayerLayerFrame;
- (void)stopPlayer;
@end
