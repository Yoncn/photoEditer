//
//  RCImagePickerViewController.m
//  demo
//
//  Created by yoncn on 2018/3/6.
//  Copyright © 2018年 yoncn. All rights reserved.
//

#import "RCImagePickerViewController.h"
#import <AVFoundation/AVFoundation.h>
#import "RCCircleProgressView.h"
#import "RCAVPlayer.h"
#import "ButtonExtension.h"
#import <Photos/Photos.h>
#import "RCPictureEditViewController.h"
#import "UIImage+Tint.h"

#define MaxTime 10
#define MinVideoTime 0.5
#define TimerRatio 0.1
#define TakePhotoAndRecordVideoUserdefaultKey @"RCImagePicker_takePhotoAndRecordVideoKey"

#define ProgressLineWidth 6
typedef void(^PropertyChangeBlock)(AVCaptureDevice *captureDevice);
@interface RCImagePickerViewController ()<AVCaptureFileOutputRecordingDelegate, UIGestureRecognizerDelegate, RCPictureEditDelegate>
{
    BOOL _statusBarHidden;
}

@property (nonatomic, strong) UIView *AVCaptureBackgroundView;

@property (nonatomic, strong) AVCaptureSession *captureSession;
@property (nonatomic, strong) AVCaptureDeviceInput *captureDeviceInput;
@property (nonatomic, strong) AVCaptureMovieFileOutput *captureMovieFileOutput;
@property (nonatomic, strong) AVCaptureStillImageOutput *stillImageOutput;
@property (nonatomic, strong) AVCaptureVideoPreviewLayer *captureVideoPreviewLayer;

//takeVideo function view
@property (nonatomic, strong) ButtonExtension *backButton;
@property (nonatomic, strong) RCCircleProgressView *progressView;
@property (nonatomic, strong) UIView *touchView;
@property (nonatomic, strong) UIView *touchCenterView;
@property (nonatomic, strong) ButtonExtension *switchCameraButton;
@property (nonatomic, strong) UILabel *remindOperationLabel;
@property (nonatomic, strong) UIImageView *albumImageView;
@property (nonatomic, strong) UIImageView *focusCursor;

//showVideoOrImage function view
@property (nonatomic, strong) ButtonExtension *showViewBackButton;
@property (nonatomic, strong) UIButton *showViewSaveButton;
@property (nonatomic, strong) UIButton *showViewShareButton;
@property (nonatomic, strong) UIButton *showViewSendButton;
@property (nonatomic, strong) ButtonExtension *showViewEditButton;

@property (nonatomic, strong) NSURL *saveVideoUrl;
@property (nonatomic, strong) UIImage *resultImage;
@property (nonatomic, copy) NSString *resultImageId;
@property (nonatomic, assign) BOOL isVideo;
@property (nonatomic, strong) NSTimer *timer;
@property (nonatomic, assign) float currentTime;

@property (nonatomic, strong) UIView *showBackgroundView;
@property (nonatomic, strong) UIImageView *showImageView;
@property (nonatomic, strong) RCAVPlayer *player;


@end

@implementation RCImagePickerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self configShotUI];
    [self configShowUI];
    
    if ([self setupSession]) {
        [self.captureSession startRunning];
    }
    
    [self setupObservers];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = YES;
    self.view.backgroundColor = [UIColor blackColor];
    if (self.saveVideoUrl) {
        self.player.videoUrl = self.saveVideoUrl;
    }
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    _statusBarHidden = YES;
    [self setNeedsStatusBarAppearanceUpdate];
    
}

- (void)viewDidLayoutSubviews {
    if (IS_IPAD) {
        if ([self.captureMovieFileOutput isRecording]) {
            [self endRecord];
        }
        self.AVCaptureBackgroundView.frame = self.view.bounds;
        self.showBackgroundView.frame = self.AVCaptureBackgroundView.frame;
        self.captureVideoPreviewLayer.frame = self.AVCaptureBackgroundView.frame;
        CGFloat touchViewWidth = 62;
        _touchView.frame = CGRectMake((self.AVCaptureBackgroundView.bounds.size.width - _touchView.frame.size.width)/2, self.AVCaptureBackgroundView.bounds.size.height - _touchView.frame.size.width - 57, touchViewWidth, touchViewWidth);
        _touchCenterView.center = _touchView.center;
        CGFloat progressViewWidth = 73 - ProgressLineWidth/2;
        _progressView.frame = CGRectMake((self.AVCaptureBackgroundView.bounds.size.width - progressViewWidth)/2, self.AVCaptureBackgroundView.bounds.size.height - progressViewWidth - 52, progressViewWidth, progressViewWidth);
        _remindOperationLabel.frame = CGRectMake(0, _progressView.frame.origin.y - 41 - 16, self.AVCaptureBackgroundView.bounds.size.width, 16);
        
        CGFloat albumBorderWidth = 2;
        CGFloat albumWidth = 32 + albumBorderWidth*2;
        CGFloat albumRightPadding = (self.AVCaptureBackgroundView.bounds.size.width - (_progressView.frame.origin.x + _progressView.frame.size.width))/2;
        _albumImageView.frame = CGRectMake(self.AVCaptureBackgroundView.bounds.size.width - albumRightPadding - albumWidth/2, _touchView.frame.origin.y + touchViewWidth/2 - albumWidth/2, albumWidth, albumWidth);
        CGFloat backButtonWidth = 28;
        _backButton.frame = CGRectMake((_progressView.frame.origin.x - backButtonWidth)/2, _touchView.frame.origin.y + touchViewWidth/2 - backButtonWidth/2, backButtonWidth, backButtonWidth);
        
        CGFloat switchCameraButtonWidth = 36;
        CGFloat switchCameraPadding = 14;
        _switchCameraButton.frame = CGRectMake(self.AVCaptureBackgroundView.bounds.size.width - switchCameraPadding -switchCameraButtonWidth, switchCameraPadding, switchCameraButtonWidth, switchCameraButtonWidth);
        
        if ([self.captureVideoPreviewLayer.connection isVideoOrientationSupported]) {
            [self.captureVideoPreviewLayer.connection setVideoOrientation:[self avOrientationForDeviceOrientation:[UIDevice currentDevice].orientation]];
        }
        
        _showViewBackButton.frame = CGRectMake(16, 20, 24, 24);
        _showViewSaveButton.frame = CGRectMake(0, _showBackgroundView.bounds.size.height - 16 - 50, 64, 50);
        _showViewShareButton.frame = CGRectMake(_showViewSaveButton.frame.size.width, _showBackgroundView.bounds.size.height - 16 - 46, 64, 46);
        CGSize sendButtonSize = CGSizeMake(50, 50);
        _showViewSendButton.frame = CGRectMake(_showBackgroundView.bounds.size.width - 16 - sendButtonSize.width, _showBackgroundView.bounds.size.height - 16 - sendButtonSize.height, sendButtonSize.width, sendButtonSize.height);
        if (_player) {
            self.player.frame = self.showBackgroundView.bounds;
            [self.player refreshPlayerLayerFrame];
        }
        if (_showImageView) {
            self.showImageView.frame = self.showBackgroundView.bounds;
        }
        
    }
}


- (void)configShotUI {
    _currentTime = 0;
    CGRect allBackgroudFrame = self.view.bounds;
    if (IS_IPHONEX) {
        CGFloat padding = 34;
        allBackgroudFrame = CGRectMake(0, 44 + padding, self.view.bounds.size.width, self.view.bounds.size.height - 44 - 34 - padding*2);
    }
    self.AVCaptureBackgroundView = [[UIView alloc] initWithFrame:allBackgroudFrame];
    UIPinchGestureRecognizer *pinch = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(pinchAction:)];
    pinch.delegate = self;
    [self.AVCaptureBackgroundView addGestureRecognizer:pinch];
    UITapGestureRecognizer *doubleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(doubleTapAction:)];
    doubleTap.numberOfTapsRequired = 2;
    doubleTap.delegate = self;
    [self.AVCaptureBackgroundView addGestureRecognizer:doubleTap];
    UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(singleTapAction:)];
    [self.AVCaptureBackgroundView addGestureRecognizer:singleTap];
    singleTap.delegate = self;
    [singleTap requireGestureRecognizerToFail:doubleTap];
    self.AVCaptureBackgroundView.userInteractionEnabled = YES;
    
    [self.view addSubview:self.AVCaptureBackgroundView];
    
    _touchCenterView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 1, 1)];
    _touchCenterView.backgroundColor = [UIColor redColor];
    _touchCenterView.layer.masksToBounds = YES;
    _touchCenterView.userInteractionEnabled = NO;
    _touchCenterView.hidden = YES;
    [self.AVCaptureBackgroundView addSubview:_touchCenterView];
    
    CGFloat touchViewWidth = 62;
    _touchView = [[UIView alloc] initWithFrame:CGRectMake((self.AVCaptureBackgroundView.bounds.size.width - touchViewWidth)/2, self.AVCaptureBackgroundView.bounds.size.height - touchViewWidth - 57, touchViewWidth, touchViewWidth)];
    _touchView.backgroundColor = [UIColor clearColor];
    _touchView.layer.cornerRadius = touchViewWidth/2;
    _touchView.layer.masksToBounds = YES;
    _touchView.userInteractionEnabled = YES;
    [self.AVCaptureBackgroundView addSubview:_touchView];
    
    _touchCenterView.center = _touchView.center;
    
    CGFloat progressViewWidth = 73 - ProgressLineWidth/2;
    _progressView = [[RCCircleProgressView alloc] initWithFrame:CGRectMake((self.AVCaptureBackgroundView.bounds.size.width - progressViewWidth)/2, self.AVCaptureBackgroundView.bounds.size.height - progressViewWidth - 52, progressViewWidth, progressViewWidth) defaultColor:[UIColor whiteColor] progressColor:[UIColor redColor] lineWidth:ProgressLineWidth];
    [self.AVCaptureBackgroundView addSubview:_progressView];
    
    if (![[NSUserDefaults standardUserDefaults] boolForKey:TakePhotoAndRecordVideoUserdefaultKey]) {
        _remindOperationLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, _progressView.frame.origin.y - 41 - 16, self.AVCaptureBackgroundView.bounds.size.width, 16)];
        _remindOperationLabel.text = @"Tap to take photo and hold to record video";
        _remindOperationLabel.textColor = [UIColor whiteColor];
        _remindOperationLabel.textAlignment = NSTextAlignmentCenter;
        _remindOperationLabel.font = [UIFont systemFontOfSize:14];
        _remindOperationLabel.layer.shadowColor = [[[UIColor blackColor] colorWithAlphaComponent:0.4] CGColor];
        _remindOperationLabel.layer.shadowRadius = 1.0;
        [self.AVCaptureBackgroundView addSubview:_remindOperationLabel];
    }
    
    if (self.type == ImagePickerTypeVideoAndImageAndAlbum) {
        CGFloat albumBorderWidth = 2;
        CGFloat albumWidth = 32 + albumBorderWidth*2;
        CGFloat albumRightPadding = (self.AVCaptureBackgroundView.bounds.size.width - (_progressView.frame.origin.x + _progressView.frame.size.width))/2;
        _albumImageView = [[UIImageView alloc] initWithFrame:CGRectMake(self.AVCaptureBackgroundView.bounds.size.width - albumRightPadding - albumWidth/2, _touchView.frame.origin.y + touchViewWidth/2 - albumWidth/2, albumWidth, albumWidth)];
        _albumImageView.layer.borderColor = [[UIColor whiteColor] CGColor];
        _albumImageView.layer.borderWidth = albumBorderWidth;
        _albumImageView.layer.cornerRadius = albumWidth/2;
        _albumImageView.layer.masksToBounds = YES;
        _albumImageView.userInteractionEnabled = YES;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAlbumImageViewToOpenAlbum)];
        [_albumImageView addGestureRecognizer:tap];
        [self.AVCaptureBackgroundView addSubview:_albumImageView];
        [self getAlbumlastImageToRefreshAlbumImageView];
    }
    
    CGFloat backButtonWidth = 28;
    _backButton = [ButtonExtension buttonWithType:UIButtonTypeCustom];
    _backButton.frame = CGRectMake((_progressView.frame.origin.x - backButtonWidth)/2, _touchView.frame.origin.y + touchViewWidth/2 - backButtonWidth/2, backButtonWidth, backButtonWidth);
    [_backButton setBackgroundImage:[UIImage imageNamed:@"downBack"] forState:UIControlStateNormal];
    [_backButton setBackgroundImage:[UIImage imageByApplyingAlphaWithImage:[UIImage imageNamed:@"downBack"]] forState:UIControlStateHighlighted];
    [_backButton addTarget:self action:@selector(dismissImagePicker) forControlEvents:UIControlEventTouchUpInside];
    [self.AVCaptureBackgroundView addSubview:_backButton];
    
    CGFloat switchCameraButtonWidth = 36;
    CGFloat switchCameraPadding = 14;
    _switchCameraButton = [ButtonExtension buttonWithType:UIButtonTypeCustom];
    _switchCameraButton.frame = CGRectMake(self.AVCaptureBackgroundView.bounds.size.width - switchCameraPadding -switchCameraButtonWidth, switchCameraPadding, switchCameraButtonWidth, switchCameraButtonWidth);
    [_switchCameraButton setBackgroundImage:[UIImage imageNamed:@"shoot-camera-switch"] forState:UIControlStateNormal];
    [_switchCameraButton setBackgroundImage:[UIImage imageByApplyingAlphaWithImage:[UIImage imageNamed:@"shoot-camera-switch"]] forState:UIControlStateHighlighted];
    [_switchCameraButton addTarget:self action:@selector(switchCamera) forControlEvents:UIControlEventTouchUpInside];
    [self.AVCaptureBackgroundView addSubview:_switchCameraButton];
    
    _focusCursor = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 75, 75)];
    _focusCursor.hidden = YES;
    _focusCursor.image = [UIImage imageNamed:@"brightnessAdjustmentIndicator"];
    [self.AVCaptureBackgroundView addSubview:_focusCursor];
    
    [self.AVCaptureBackgroundView insertSubview:_touchView atIndex:self.AVCaptureBackgroundView.subviews.count - 1];
}

- (void)configShowUI {
    _showBackgroundView = [[UIView alloc] initWithFrame:self.AVCaptureBackgroundView.frame];
    [self.view addSubview:_showBackgroundView];
    _showBackgroundView.alpha = 0;
    _showBackgroundView.hidden = YES;
    
    _showViewBackButton = [ButtonExtension buttonWithType:UIButtonTypeCustom];
    _showViewBackButton.frame = CGRectMake(16, 20, 24, 24);
    [_showViewBackButton addTarget:self action:@selector(showViewBackToShot) forControlEvents:UIControlEventTouchUpInside];
    [_showViewBackButton setBackgroundImage:[UIImage imageNamed:@"shootCancel"] forState:UIControlStateNormal];
    [_showViewBackButton setBackgroundImage:[UIImage imageByApplyingAlphaWithImage:[UIImage imageNamed:@"shootCancel"]] forState:UIControlStateHighlighted];
    [_showBackgroundView addSubview:_showViewBackButton];
    
    _showViewSaveButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _showViewSaveButton.frame = CGRectMake(0, _showBackgroundView.bounds.size.height - 16 - 46, 64, 46);
    [_showViewSaveButton addTarget:self action:@selector(showViewSave) forControlEvents:UIControlEventTouchUpInside];
    [_showViewSaveButton setImage:[UIImage imageNamed:@"download"] forState:UIControlStateNormal];
    [_showViewSaveButton setImage:[UIImage imageByApplyingAlphaWithImage:[UIImage imageNamed:@"download"]] forState:UIControlStateHighlighted];
    [_showViewSaveButton setTitle:@"save" forState:UIControlStateNormal];
    [_showViewSaveButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [_showViewSaveButton setTitleColor:[[UIColor whiteColor] colorWithAlphaComponent:0.3] forState:UIControlStateHighlighted];
    _showViewSaveButton.titleLabel.font = [UIFont systemFontOfSize:13];
    _showViewSaveButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    _showViewSaveButton.titleEdgeInsets = UIEdgeInsetsMake(0, -_showViewSaveButton.imageView.frame.size.width, -_showViewSaveButton.imageView.frame.size.height - 10, 0);
    _showViewSaveButton.imageEdgeInsets = UIEdgeInsetsMake(-_showViewSaveButton.titleLabel.frame.size.height, 0, 0, -_showViewSaveButton.titleLabel.frame.size.width);
    [_showBackgroundView addSubview:_showViewSaveButton];
    
    
    _showViewShareButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _showViewShareButton.frame = CGRectMake(_showViewSaveButton.frame.size.width, _showBackgroundView.bounds.size.height - 16 - 46, 64, 46);
    [_showViewShareButton addTarget:self action:@selector(showViewShare:) forControlEvents:UIControlEventTouchUpInside];
    [_showViewShareButton setImage:[UIImage imageNamed:@"shootShare"] forState:UIControlStateNormal];
    [_showViewShareButton setImage:[UIImage imageByApplyingAlphaWithImage:[UIImage imageNamed:@"shootShare"]] forState:UIControlStateHighlighted];
    [_showViewShareButton setTitle:@"share" forState:UIControlStateNormal];
    [_showViewShareButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [_showViewShareButton setTitleColor:[[UIColor whiteColor] colorWithAlphaComponent:0.3] forState:UIControlStateHighlighted];
    _showViewShareButton.titleLabel.font = [UIFont systemFontOfSize:13];
    _showViewShareButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    _showViewShareButton.titleEdgeInsets = UIEdgeInsetsMake(0, -_showViewShareButton.imageView.frame.size.width, -_showViewShareButton.imageView.frame.size.height - 10, 0);
    _showViewShareButton.imageEdgeInsets = UIEdgeInsetsMake(-_showViewShareButton.titleLabel.frame.size.height, 0, 0, -_showViewShareButton.titleLabel.frame.size.width);
    [_showBackgroundView addSubview:_showViewShareButton];
    
    _showViewEditButton = [ButtonExtension buttonWithType:UIButtonTypeCustom];
    _showViewEditButton.frame = CGRectMake(_showBackgroundView.bounds.size.width - 16 - 24, 20, 24, 24);
    [_showViewEditButton setBackgroundImage:[UIImage imageNamed:@"camera-edit"] forState:UIControlStateNormal];
    [_showViewEditButton setBackgroundImage:[UIImage imageByApplyingAlphaWithImage:[UIImage imageNamed:@"camera-edit"]] forState:UIControlStateHighlighted];
    [_showViewEditButton addTarget:self action:@selector(showViewEditImage) forControlEvents:UIControlEventTouchUpInside];
    _showViewEditButton.hidden = YES;
    [_showBackgroundView addSubview:_showViewEditButton];
    
    
    CGSize sendButtonSize = CGSizeMake(50, 50);
    _showViewSendButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _showViewSendButton.frame = CGRectMake(_showBackgroundView.bounds.size.width - 16 - sendButtonSize.width, _showBackgroundView.bounds.size.height - 16 - sendButtonSize.height, sendButtonSize.width, sendButtonSize.height);
    [_showViewSendButton addTarget:self action:@selector(showViewSendMessage) forControlEvents:UIControlEventTouchUpInside];
    [_showViewSendButton setImage:[UIImage imageNamed:@"common-send"] forState:UIControlStateNormal];
    [_showViewSendButton setImage:[UIImage imageNamed:@"common-send"] forState:UIControlStateHighlighted];
    [_showViewSendButton setBackgroundImage:[UIImage templateCircleImageWithSize:sendButtonSize radius:50/2.0f] forState:UIControlStateNormal];
    [_showViewSendButton setBackgroundImage:[UIImage imageByApplyingAlphaWithImage:[UIImage circleImageWithColor:[UIColor redColor] size:sendButtonSize radius:50/2.0f]] forState:UIControlStateHighlighted];
    _showViewSendButton.tintColor = [UIColor redColor];
    _showViewSendButton.layer.cornerRadius = 50/2.0f;
    _showViewSendButton.layer.shadowRadius = 4.0f;
    _showViewSendButton.layer.shadowColor = [[[UIColor blackColor] colorWithAlphaComponent:0.2] CGColor];
    [_showBackgroundView addSubview:_showViewSendButton];
}


- (BOOL)setupSession {
    self.captureSession = ({
        AVCaptureSession *session = [[AVCaptureSession alloc] init];
        if (IS_IPHONEX) {
            if ([session canSetSessionPreset:AVCaptureSessionPreset1920x1080]) {
                [session setSessionPreset:AVCaptureSessionPreset1920x1080];
            }
        } else {
            if ([session canSetSessionPreset:AVCaptureSessionPresetHigh]) {
                [session setSessionPreset:AVCaptureSessionPresetHigh];
            }
        }
        
        session;
    });
    
    //视频输入
    AVCaptureDevice *captureDevice = [self getCameraDeviceWithPosition:AVCaptureDevicePositionBack];
    NSError *error = nil;
    self.captureDeviceInput = [[AVCaptureDeviceInput alloc] initWithDevice:captureDevice error:&error];
    if (error) {
        NSLog(@"captureDeviceInput error:%@",error.localizedDescription);
        return NO;
    }
    
    //音频输入
    AVCaptureDevice *audioCaptureDevice = [[AVCaptureDevice devicesWithMediaType:AVMediaTypeAudio] firstObject];
    error = nil;
    AVCaptureDeviceInput *audioCaptureDeviceInput = [[AVCaptureDeviceInput alloc] initWithDevice:audioCaptureDevice error:&error];
    if (error) {
        NSLog(@"audioCaptureDeviceInput error:%@",error.localizedDescription);
        return NO;
    }
    
    //将输入设备添加到会话
    if ([self.captureSession canAddInput:self.captureDeviceInput]) {
        [self.captureSession addInput:self.captureDeviceInput];
        [self.captureSession addInput:audioCaptureDeviceInput];
        //视频防抖
        AVCaptureConnection *connection = [self.captureMovieFileOutput connectionWithMediaType:AVMediaTypeVideo];
        if ([connection isVideoStabilizationSupported]) {
            connection.preferredVideoStabilizationMode = AVCaptureVideoStabilizationModeCinematic;
        }
    }
    
    //设备输出
    self.captureMovieFileOutput = [[AVCaptureMovieFileOutput alloc] init];
    if ([self.captureSession canAddOutput:self.captureMovieFileOutput]) {
        [self.captureSession addOutput:self.captureMovieFileOutput];
    }
    
    //照片输出
    self.stillImageOutput = [[AVCaptureStillImageOutput alloc] init];
    NSDictionary *outputSettings = [[NSDictionary alloc] initWithObjectsAndKeys:AVVideoCodecJPEG, AVVideoCodecKey, nil];
    [self.stillImageOutput setOutputSettings:outputSettings];
    if ([self.captureSession canAddOutput:self.stillImageOutput]) {
        [self.captureSession addOutput:self.stillImageOutput];
    }
    
    //创建视频预览层
    self.captureVideoPreviewLayer = ({
        AVCaptureVideoPreviewLayer *previewLayer = [[AVCaptureVideoPreviewLayer alloc] initWithSession:self.captureSession];
        previewLayer.frame = self.AVCaptureBackgroundView.bounds;
        if (IS_IPAD) {
            previewLayer.videoGravity = AVLayerVideoGravityResizeAspect;
        } else {
            previewLayer.videoGravity = AVLayerVideoGravityResizeAspectFill;
        }
        
        if ([self.captureVideoPreviewLayer.connection isVideoOrientationSupported]) {
            [self.captureVideoPreviewLayer.connection setVideoOrientation:[self avOrientationForDeviceOrientation:[UIDevice currentDevice].orientation]];
        }
        [self.AVCaptureBackgroundView.layer insertSublayer:previewLayer atIndex:0];
        previewLayer;
        
    });
    return YES;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    if ([[touches anyObject] view] == self.touchView) {
        NSLog(@"begin touch");
        //根据设备输出获得连接
        AVCaptureConnection *connection = [self.captureMovieFileOutput connectionWithMediaType:AVMediaTypeVideo];
        //根据连接取得设备输出的数据
        if (![self.captureMovieFileOutput isRecording]) {
            //如果支持多任务则开始多任务
            if ([[UIDevice currentDevice] isMultitaskingSupported]) {
//                self.backgroundTaskIdentifier = [[UIApplication sharedApplication] beginBackgroundTaskWithExpirationHandler:nil];
            }
            if (self.saveVideoUrl) {
                [[NSFileManager defaultManager] removeItemAtURL:self.saveVideoUrl error:nil];
            }
            if ([connection isVideoOrientationSupported]) {
                connection.videoOrientation = [self avOrientationForDeviceOrientation:[UIDevice currentDevice].orientation];
            }
            if ([connection isVideoMirroringSupported]) {
                AVCaptureDevicePosition currentPosition=[[self.captureDeviceInput device] position];
                if (currentPosition == AVCaptureDevicePositionUnspecified || currentPosition == AVCaptureDevicePositionFront) {
                    connection.videoMirrored = YES;
                } else {
                    connection.videoMirrored = NO;
                }
            }
            NSString *outputFielPath = [NSTemporaryDirectory() stringByAppendingString:@"myMovie.mov"];
            NSLog(@"save path is :%@",outputFielPath);

            [self.captureMovieFileOutput startRecordingToOutputFileURL:[NSURL fileURLWithPath:outputFielPath] recordingDelegate:self];
            
            if (![[NSUserDefaults standardUserDefaults] boolForKey:TakePhotoAndRecordVideoUserdefaultKey]) {
                [_remindOperationLabel removeFromSuperview];
                [[NSUserDefaults standardUserDefaults] setBool:YES forKey:TakePhotoAndRecordVideoUserdefaultKey];
            }
            [self resetTimerAndCount];
            [self.timer fire];
        } else {
            [self.captureMovieFileOutput stopRecording];
        }
    }
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(nullable UIEvent *)event {
    UITouch *touch = [touches anyObject];
    if ([touch view] == self.touchView) {
        CGPoint fullScreenLocation = [touch locationInView:self.AVCaptureBackgroundView];
        NSLog(@"yyy:%lf",fullScreenLocation.y);
        if (fullScreenLocation.y < self.progressView.frame.origin.y) {
            CGPoint location = [touch locationInView:self.touchView];
            CGPoint previousLocation = [touch previousLocationInView:self.touchView];
            CGFloat locationYChange = location.y - previousLocation.y;
            
            AVCaptureDevice *captureDevice = [self.captureDeviceInput device];
            CGFloat newVideoScale = captureDevice.videoZoomFactor - locationYChange/30;
            newVideoScale = newVideoScale < 1.0 ? 1.0 : newVideoScale;
            newVideoScale = newVideoScale > captureDevice.activeFormat.videoMaxZoomFactor ? captureDevice.activeFormat.videoMaxZoomFactor : newVideoScale;
            [self setVideoZoomFactor:newVideoScale];
        }
    }
}


- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    if ([[touches anyObject] view] == self.touchView) {
        NSLog(@"end touch");
        [self endRecord];
    }
}

- (void)endRecord {
    [self.captureMovieFileOutput stopRecording];//停止录制
    [self resetTimerAndCount];
    self.backButton.hidden = YES;
    self.switchCameraButton.hidden = YES;
    self.progressView.hidden = YES;
    self.touchView.hidden = YES;
    self.touchCenterView.hidden = YES;
    self.albumImageView.hidden = YES;
}

- (void)switchCamera {
    NSLog(@"switch camera");
    AVCaptureDevice *currentDevice = [self.captureDeviceInput device];
    AVCaptureDevicePosition currentPosition = [currentDevice position];
    [self removeNotificationFromCaptureDevice:currentDevice];
    AVCaptureDevice *toChangeDevice;
    
    AVCaptureDevicePosition toChangePosition = AVCaptureDevicePositionFront;//前
    if (currentPosition == AVCaptureDevicePositionUnspecified || currentPosition == AVCaptureDevicePositionFront) {
        toChangePosition = AVCaptureDevicePositionBack;//后
    }
    toChangeDevice = [self getCameraDeviceWithPosition:toChangePosition];
    [self addNotificationToCaptureDevice:toChangeDevice];
    //新输入
    AVCaptureDeviceInput *newCaptureDeviceInput = [[AVCaptureDeviceInput alloc] initWithDevice:toChangeDevice error:nil];
    
    
    [self.captureSession beginConfiguration];
    
    //移除原有对象
    [self.captureSession removeInput:self.captureDeviceInput];
    //添加新的对象
    if ([self.captureSession canAddInput:newCaptureDeviceInput]) {
        [self.captureSession addInput:newCaptureDeviceInput];
        self.captureDeviceInput = newCaptureDeviceInput;
    }

    [self.captureSession commitConfiguration];
}


- (void)captureOutput:(AVCaptureFileOutput *)captureOutput didStartRecordingToOutputFileAtURL:(NSURL *)fileURL fromConnections:(NSArray *)connections{
    NSLog(@"begin record");
}


- (void)captureOutput:(AVCaptureFileOutput *)captureOutput didFinishRecordingToOutputFileAtURL:(NSURL *)outputFileURL fromConnections:(NSArray *)connections error:(NSError *)error{
    NSLog(@"end record");
    
    if (self.isVideo) {
        if (outputFileURL) {
            [self.captureSession stopRunning];
            self.saveVideoUrl = outputFileURL;
            self.resultImage = nil;
            self.resultImageId = nil;
            self.player.videoUrl = outputFileURL;
            self.showImageView.hidden = YES;
            self.player.hidden = NO;
            [self transformToShowViewWithAnimation:UIDeviceOrientationIsPortrait([UIDevice currentDevice].orientation)];
        } else {
            NSLog(@"outputFileURL not exsit");
        }
    } else {
        //照片
        self.showImageView.hidden = NO;
        self.player.hidden = YES;
        self.saveVideoUrl = nil;
        [self videoHandlePhoto:outputFileURL];
    }
    
    
}

- (void)videoHandlePhoto:(NSURL *)url {
    AVCaptureConnection *imageConnection = [self.stillImageOutput connectionWithMediaType:AVMediaTypeVideo];
    if (!imageConnection) {
        return;
    }
    if ([imageConnection isVideoOrientationSupported]) {
        imageConnection.videoOrientation = [self avOrientationForDeviceOrientation:[UIDevice currentDevice].orientation];
    }
    if ([imageConnection isVideoMirroringSupported]) {
        AVCaptureDevicePosition currentPosition = [[self.captureDeviceInput device] position];
        if (currentPosition == AVCaptureDevicePositionUnspecified || currentPosition == AVCaptureDevicePositionFront) {
            imageConnection.videoMirrored = YES;
        } else {
            imageConnection.videoMirrored = NO;
        }
    }
    [self.stillImageOutput captureStillImageAsynchronouslyFromConnection:imageConnection completionHandler:^(CMSampleBufferRef imageDataSampleBuffer, NSError *error) {
        if (imageDataSampleBuffer == NULL) {
            return;
        }
        [self.captureSession stopRunning];
        NSData *imageData = [AVCaptureStillImageOutput jpegStillImageNSDataRepresentation:imageDataSampleBuffer];
        UIImage *image = [UIImage imageWithData:imageData];
        
        if (!image) {
            AVURLAsset *urlSet = [AVURLAsset assetWithURL:url];
            AVAssetImageGenerator *imageGenerator = [AVAssetImageGenerator assetImageGeneratorWithAsset:urlSet];
            imageGenerator.appliesPreferredTrackTransform = YES;
            NSError *error = nil;
            CMTime actucalTime;
            CGImageRef cgImage = [imageGenerator copyCGImageAtTime:urlSet.duration actualTime:&actucalTime error:&error];
            CMTimeShow(actucalTime);
            UIImage *image = [UIImage imageWithCGImage:cgImage];
            CGImageRelease(cgImage);
            if (!image) {
                if (error) {
                    NSLog(@"RCImagePickerVC get image failed, error:%@", error.localizedDescription);
                }
                [self showViewBackToShot];
                return;
            }
        }
        
        self.resultImage = image;
        self.resultImageId = nil;
        [[NSFileManager defaultManager] removeItemAtURL:url error:nil];
        
        self.showImageView.image = self.resultImage;
        [self transformToShowViewWithAnimation:NO];
    }];
    
}

- (AVCaptureVideoOrientation)avOrientationForDeviceOrientation:(UIDeviceOrientation)deviceOrientation {
    switch (deviceOrientation) {
        case UIDeviceOrientationPortrait:
            return AVCaptureVideoOrientationPortrait;
            break;
        case UIDeviceOrientationLandscapeLeft:
            return AVCaptureVideoOrientationLandscapeRight;
            break;
        case UIDeviceOrientationLandscapeRight:
            return AVCaptureVideoOrientationLandscapeLeft;
            break;
        case UIDeviceOrientationPortraitUpsideDown:
            return AVCaptureVideoOrientationPortraitUpsideDown;
            break;
        default:
            return AVCaptureVideoOrientationPortrait;
            break;
    }
}


#pragma mark - notification

- (void)setupObservers {
    NSNotificationCenter *notification = [NSNotificationCenter defaultCenter];
    [notification addObserver:self selector:@selector(applicationDidEnterBackground:) name:UIApplicationWillResignActiveNotification object:[UIApplication sharedApplication]];
    [notification addObserver:self selector:@selector(applicationDidEnterForground:) name:UIApplicationWillEnterForegroundNotification object:[UIApplication sharedApplication]];
    [notification addObserver:self selector:@selector(applicationDidchangeOrientation:) name:UIDeviceOrientationDidChangeNotification object:nil];
}

- (void)applicationDidEnterBackground:(NSNotification *)notification {
    if (!_resultImage && !_saveVideoUrl && self.type != ImagePickerTypeVideoAndImageAndAlbum) {
        [self dismissImagePicker];
    }
    if (self.saveVideoUrl) {
        [self.player stopPlayer];
    }
}

- (void)applicationDidEnterForground:(NSNotification *)notification {
    if (self.saveVideoUrl) {
        self.player.videoUrl = self.saveVideoUrl;
    }
}

- (void)applicationDidchangeOrientation:(NSNotification *)notification {
    UIDeviceOrientation orientation = [UIDevice currentDevice].orientation;
    if (orientation == UIDeviceOrientationFaceUp
        || orientation == UIDeviceOrientationFaceDown
        || orientation == UIDeviceOrientationUnknown || IS_IPAD) {
        return;
    }
    CGFloat angle;
    switch(orientation) {
        case UIDeviceOrientationPortrait:
            angle = 0;
            break;
        case UIDeviceOrientationLandscapeLeft:
            angle = M_PI/2;
            break;
        case UIDeviceOrientationPortraitUpsideDown:
            angle = M_PI;
            break;
        case UIDeviceOrientationLandscapeRight:
            angle = -M_PI/2;
            break;
        default:
            return;
    }
    [UIView animateWithDuration:0.29 animations:^{
        _switchCameraButton.transform = CGAffineTransformMakeRotation(angle);
    } completion:^(BOOL finished) {
        
    }];
}


- (void)addNotificationToCaptureDevice:(AVCaptureDevice *)captureDevice {
    //注意添加区域改变捕获通知必须首先设置设备允许捕获
    [self changeDeviceProperty:^(AVCaptureDevice *captureDevice) {
        captureDevice.subjectAreaChangeMonitoringEnabled=YES;
    }];
    NSNotificationCenter *notificationCenter= [NSNotificationCenter defaultCenter];
    //捕获区域发生改变
    [notificationCenter addObserver:self selector:@selector(areaChange:) name:AVCaptureDeviceSubjectAreaDidChangeNotification object:captureDevice];
}

- (void)removeNotificationFromCaptureDevice:(AVCaptureDevice *)captureDevice {
    NSNotificationCenter *notificationCenter= [NSNotificationCenter defaultCenter];
    [notificationCenter removeObserver:self name:AVCaptureDeviceSubjectAreaDidChangeNotification object:captureDevice];
}

- (void)removeNotification {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)addNotificationToCaptureSession:(AVCaptureSession *)captureSession {
    NSNotificationCenter *notificationCenter= [NSNotificationCenter defaultCenter];
    //会话出错
    [notificationCenter addObserver:self selector:@selector(sessionRuntimeError:) name:AVCaptureSessionRuntimeErrorNotification object:captureSession];
}

/**
 *  设备连接成功
 */
- (void)deviceConnected:(NSNotification *)notification {
}
/**
 *  设备连接断开
*/
- (void)deviceDisconnected:(NSNotification *)notification {
}
/**
 *  捕获区域改变
*/
- (void)areaChange:(NSNotification *)notification {
}

/**
 *  会话出错
*/
- (void)sessionRuntimeError:(NSNotification *)notification {
}



/**
 *  取得指定位置的摄像头
 *
 *  @param position 摄像头位置
 *
 *  @return 摄像头设备
 */
- (AVCaptureDevice *)getCameraDeviceWithPosition:(AVCaptureDevicePosition )position{
    NSArray *cameras= [AVCaptureDevice devicesWithMediaType:AVMediaTypeVideo];
    for (AVCaptureDevice *camera in cameras) {
        if ([camera position] == position) {
            return camera;
        }
    }
    return nil;
}

/**
 *  改变设备属性的统一操作方法
 *
 *  @param propertyChange 属性改变操作
 */
- (void)changeDeviceProperty:(PropertyChangeBlock)propertyChange {
    AVCaptureDevice *captureDevice = [self.captureDeviceInput device];
    NSError *error;
    //注意改变设备属性前一定要首先调用lockForConfiguration:调用完之后使用unlockForConfiguration方法解锁
    if ([captureDevice lockForConfiguration:&error]) {
        //自动白平衡
        if ([captureDevice isWhiteBalanceModeSupported:AVCaptureWhiteBalanceModeContinuousAutoWhiteBalance]) {
            [captureDevice setWhiteBalanceMode:AVCaptureWhiteBalanceModeContinuousAutoWhiteBalance];
        }
        //自动根据环境条件开启闪光灯
        if ([captureDevice isFlashModeSupported:AVCaptureFlashModeAuto]) {
            [captureDevice setFlashMode:AVCaptureFlashModeAuto];
        }
        
        propertyChange(captureDevice);
        [captureDevice unlockForConfiguration];
    } else {
        NSLog(@"device attribute error : %@", error.localizedDescription);
    }
}

/**
 *  设置闪光灯模式
 *
 *  @param flashMode 闪光灯模式
 */
- (void)setFlashMode:(AVCaptureFlashMode )flashMode {
    [self changeDeviceProperty:^(AVCaptureDevice *captureDevice) {
        if ([captureDevice isFlashModeSupported:flashMode]) {
            [captureDevice setFlashMode:flashMode];
        }
    }];
}
/**
 *  设置聚焦模式
 *
 *  @param focusMode 聚焦模式
 */
- (void)setFocusMode:(AVCaptureFocusMode )focusMode {
    [self changeDeviceProperty:^(AVCaptureDevice *captureDevice) {
        if ([captureDevice isFocusModeSupported:focusMode]) {
            [captureDevice setFocusMode:focusMode];
        }
    }];
}
/**
 *  设置曝光模式
 *
 *  @param exposureMode 曝光模式
 */
- (void)setExposureMode:(AVCaptureExposureMode)exposureMode {
    [self changeDeviceProperty:^(AVCaptureDevice *captureDevice) {
        if ([captureDevice isExposureModeSupported:exposureMode]) {
            [captureDevice setExposureMode:exposureMode];
        }
    }];
}

/**
 *  设置焦距
 *
 *  @param videoZoomFactor 焦距
 */
- (void)setVideoZoomFactor:(CGFloat)videoZoomFactor {
    [self changeDeviceProperty:^(AVCaptureDevice *captureDevice) {
        [captureDevice setVideoZoomFactor:videoZoomFactor];
    }];
}

/**
 *  设置聚焦点
 *
 *  @param point 聚焦点
 */
-(void)focusWithMode:(AVCaptureFocusMode)focusMode exposureMode:(AVCaptureExposureMode)exposureMode atPoint:(CGPoint)point{
    [self changeDeviceProperty:^(AVCaptureDevice *captureDevice) {
        if ([captureDevice isFocusPointOfInterestSupported]) {
            [captureDevice setFocusPointOfInterest:point];
        }
        if ([captureDevice isExposurePointOfInterestSupported]) {
            [captureDevice setExposurePointOfInterest:point];
        }
        if ([captureDevice isExposureModeSupported:exposureMode]) {
            [captureDevice setExposureMode:exposureMode];
        }
        if ([captureDevice isFocusModeSupported:focusMode]) {
            [captureDevice setFocusMode:focusMode];
        }
    }];
}

/**
 *  设置聚焦光标位置
 *
 *  @param point 光标位置
 */
- (void)setFocusCursorWithPoint:(CGPoint)point {
    if (_focusCursor.hidden) {
        _focusCursor.center = point;
        _focusCursor.transform = CGAffineTransformMakeScale(1.25, 1.25);
        _focusCursor.hidden = NO;
        [UIView animateWithDuration:0.29 animations:^{
            _focusCursor.transform = CGAffineTransformIdentity;
        } completion:^(BOOL finished) {
            [self performSelector:@selector(onHiddenFocusCurSorAction) withObject:nil afterDelay:0.5];
        }];
    }
}

- (void)onHiddenFocusCurSorAction {
    _focusCursor.hidden = YES;
}

#pragma mark - action

/**
 *  计数
 */
- (void)startCount {
    _currentTime = _currentTime + TimerRatio;
    BOOL oldIsVideo = self.isVideo;
    self.isVideo = self.type == ImagePickerTypeImage ? NO : (_currentTime > MinVideoTime);
    if (self.isVideo) {
        _touchCenterView.hidden = NO;
        _backButton.hidden = YES;
        _switchCameraButton.hidden = YES;
        _albumImageView.hidden = YES;
        _progressView.value = _currentTime/MaxTime;
        if (oldIsVideo != self.isVideo) {
            [self changeTouchCenterViewFrameAnimate:_touchView.frame shouldAnimate:YES];
            [self largerOrSmalllerProgressViewShouldLarger:YES shouldAnimate:YES];
        }
    } else {
        _touchCenterView.hidden = YES;
        _progressView.value = 0;
    }
    
    if (_currentTime >= MaxTime) {
        [self endRecord];
    }
}

- (void)changeTouchCenterViewFrameAnimate:(CGRect)frame shouldAnimate:(BOOL)animate {
    if (animate) {
        [UIView animateWithDuration:0.29 animations:^{
            _touchCenterView.bounds = frame;
            _touchCenterView.layer.cornerRadius = _touchCenterView.bounds.size.width/2;
        }];
    } else {
        _touchCenterView.bounds = frame;
        _touchCenterView.layer.cornerRadius = _touchCenterView.bounds.size.width/2;
    }
}

- (void)largerOrSmalllerProgressViewShouldLarger:(BOOL)larger shouldAnimate:(BOOL)animate {
    [self.progressView changeCircleScalePercent:(larger ? (100-ProgressLineWidth/2)*1.0/(73- ProgressLineWidth/2) : 1.0)];
}

/**
 *  重置状态
 */
- (void)resetTimerAndCount {
    [self.timer invalidate];
    self.timer = nil;
    _currentTime = 0;
    _progressView.value = 0;
    _touchCenterView.hidden = YES;
    [self changeTouchCenterViewFrameAnimate:CGRectMake(0, 0, 1, 1) shouldAnimate:NO];
}

/**
 *  进入播放或展示界面
 */
- (void)transformToShowViewWithAnimation:(BOOL)animate {
    
    _showViewEditButton.hidden = !self.resultImage;
    self.showBackgroundView.hidden = NO;
    if (animate) {
        [UIView animateWithDuration:0.29 animations:^{
            self.showBackgroundView.alpha = 1.0;
        } completion:^(BOOL finished) {
            self.AVCaptureBackgroundView.hidden = YES;
            [self setVideoZoomFactor:1.0];
        }];
    } else {
        self.showBackgroundView.alpha = 1.0;
        self.AVCaptureBackgroundView.hidden = YES;
        [self setVideoZoomFactor:1.0];
    }
    [self largerOrSmalllerProgressViewShouldLarger:NO shouldAnimate:NO];
}

/**
 *  返回重新录制
 */
- (void)showViewBackToShot {
    self.backButton.hidden = NO;
    self.switchCameraButton.hidden = NO;
    self.progressView.hidden = NO;
    self.touchView.hidden = NO;
    self.albumImageView.hidden = NO;
    [self.captureSession startRunning];
    self.showBackgroundView.alpha = 0;
    self.showBackgroundView.hidden = YES;
    self.AVCaptureBackgroundView.hidden = NO;
    self.isVideo = NO;
    self.resultImage = nil;
    self.resultImageId = nil;
    self.saveVideoUrl = nil;
    self.touchCenterView.hidden = YES;
    [self.player removeFromSuperview];
    self.player = nil;
    [self.player stopPlayer];
}

/**
 *  保存
 */
- (void)showViewSave {
    
}


/**
 *  分享
 */
- (void)showViewShare:(id)sender {
    
}

/**
 *  编辑图片
 */
- (void)showViewEditImage {
    if (!self.resultImage) {
        return;
    }
    RCPictureEditViewController *vc = [[RCPictureEditViewController alloc] initWithImage:self.resultImage];
    vc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    vc.pictureEditDelegate = self;
    [self presentViewController:vc animated:YES completion:^{
        
    }];
}

/**
 *  发送
 */
- (void)showViewSendMessage {
    if (self.saveVideoUrl) {
        [self.player stopPlayer];
    }
    if ([self.delegate respondsToSelector:@selector(RCImagepickerDidFinishShotViewController:andVideoUrl:image:)]) {
        [self.delegate RCImagepickerDidFinishShotViewController:self andVideoUrl:self.saveVideoUrl image:self.resultImage];
    }
}


- (void)getAlbumlastImageToRefreshAlbumImageView {
    PHFetchOptions *options = [[PHFetchOptions alloc] init];
    PHFetchResult *assetsFetchResults = [PHAsset fetchAssetsWithOptions:options];
    PHAsset *phasset = [assetsFetchResults lastObject];
    PHCachingImageManager *imageManager = [[PHCachingImageManager alloc] init];
    [imageManager requestImageForAsset:phasset targetSize:CGSizeMake(32, 32) contentMode:PHImageContentModeAspectFill options:nil resultHandler:^(UIImage * _Nullable result, NSDictionary * _Nullable info) {
        if (result) {
            _albumImageView.image = result;
        } else {
            NSLog(@"get last image failed");
        }
    }];
}

#pragma mark - UIGestureRecognizer

- (void)tapAlbumImageViewToOpenAlbum {
    NSLog(@"open album");
    if ([self.delegate respondsToSelector:@selector(RCImagepickerDidTapChoosePhotoOrVideoFromAlbumOnViewController:)]) {
        [self.delegate RCImagepickerDidTapChoosePhotoOrVideoFromAlbumOnViewController:self];
    }
}

- (void)pinchAction:(UIPinchGestureRecognizer *)pinch {
    if (pinch.state == UIGestureRecognizerStateChanged) {
        CGFloat changedScale = (pinch.scale - 1.0 < 0) ? (pinch.scale-1.0)*2.5 : (pinch.scale-1.0);
        AVCaptureDevice *captureDevice = [self.captureDeviceInput device];
        CGFloat newVideoScale = captureDevice.videoZoomFactor + changedScale/15;
        newVideoScale = newVideoScale < 1.0 ? 1.0 : newVideoScale;
        newVideoScale = newVideoScale > captureDevice.activeFormat.videoMaxZoomFactor ? captureDevice.activeFormat.videoMaxZoomFactor : newVideoScale;
        [self setVideoZoomFactor:newVideoScale];
    }
}

- (void)doubleTapAction:(UITapGestureRecognizer *)doubleTap {
    [self switchCamera];
}

- (void)singleTapAction:(UITapGestureRecognizer *)singleTap {
    if ([self.captureSession isRunning]) {
        CGPoint point= [singleTap locationInView:self.AVCaptureBackgroundView];
        CGPoint cameraPoint = [self.captureVideoPreviewLayer captureDevicePointOfInterestForPoint:point];
        [self setFocusCursorWithPoint:point];
        [self focusWithMode:AVCaptureFocusModeContinuousAutoFocus exposureMode:AVCaptureExposureModeContinuousAutoExposure atPoint:cameraPoint];
    }
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch {
    if (touch.view == self.touchView) {
        return NO;
    } else {
        return YES;
    }
}

#pragma mark - RCPictureEditDelegate
//点击发送按钮的回调，image是正在编辑的图
- (void)pictureEditViewController:(RCPictureEditViewController *)pictureEditViewController sendPicture:(UIImage *)image {
    self.resultImage = image;
    self.showImageView.image = image;
    [pictureEditViewController dismissViewControllerAnimated:YES completion:nil];
}


//点击保存按钮的回调
- (void)pictureEditViewController:(RCPictureEditViewController *)pictureEditViewController savePicture:(BOOL)succeed {
    if (succeed) {
        [pictureEditViewController dismissViewControllerAnimated:YES completion:nil];
    }
}


#pragma mark - lazy load

- (NSTimer *)timer {
    if (!_timer) {
        _timer = [NSTimer scheduledTimerWithTimeInterval:TimerRatio target:self selector:@selector(startCount) userInfo:nil repeats:YES];
    }
    return _timer;
}

- (RCAVPlayer *)player {
    if (!_player) {
        _player = [[RCAVPlayer alloc] initWithFrame:self.showBackgroundView.bounds withShowInView:self.showBackgroundView];
        [self.showBackgroundView insertSubview:_player atIndex:0];
    }
    return _player;
}

- (UIImageView *)showImageView {
    if (!_showImageView) {
        _showImageView = [[UIImageView alloc] initWithFrame:self.showBackgroundView.bounds];
        _showImageView.contentMode = UIViewContentModeScaleAspectFit;
        [self.showBackgroundView insertSubview:_showImageView atIndex:0];
    }
    return _showImageView;
}

- (NSString *)resultImageId {
    if (!_resultImageId) {
        _resultImageId = [NSUUID UUID].UUIDString;
    }
    return _resultImageId;
}

- (BOOL)prefersStatusBarHidden {
    return _statusBarHidden;
}


- (void)dismissImagePicker {
    [self.timer invalidate];
    self.timer = nil;
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [self.captureSession stopRunning];
    });
    [self dismissViewControllerAnimated:YES completion:nil];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)dealloc {
    [self removeNotification];
}

@end
