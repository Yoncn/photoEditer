//
//  RCAVPlayer.m
//  demo
//
//  Created by yoncn on 2018/3/20.
//  Copyright © 2018年 yoncn. All rights reserved.
//

#import "RCAVPlayer.h"
#import <AVFoundation/AVFoundation.h>

@interface RCAVPlayer ()

@property (nonatomic,strong) AVPlayer *player;
@property (nonatomic,strong) AVPlayerLayer *playerLayer;

@end
@implementation RCAVPlayer

- (instancetype)initWithFrame:(CGRect)frame withShowInView:(UIView *)backgroundView {
    if (self = [self initWithFrame:frame]) {
        self.playerLayer = [AVPlayerLayer playerLayerWithPlayer:self.player];
        self.playerLayer.frame = self.bounds;
        [self.layer addSublayer:self.playerLayer];
        [backgroundView addSubview:self];
    }
    return self;
}

- (void)refreshPlayerLayerFrame {
    if (self.playerLayer) {
        self.playerLayer.frame = self.bounds;
    }
}

- (void)dealloc {
    [self removeAVPlayerNotification];
    [self stopPlayer];
    self.player = nil;
}

- (AVPlayer *)player {
    if (!_player) {
        _player = [AVPlayer playerWithPlayerItem:[self getAVPlayerItem]];
    }
    return _player;
}

- (AVPlayerItem *)getAVPlayerItem {
    AVPlayerItem *playerItem = [AVPlayerItem playerItemWithURL:self.videoUrl];
    return playerItem;
}

- (void)setVideoUrl:(NSURL *)videoUrl {
    _videoUrl = videoUrl;
    [self removeAVPlayerNotification];
    [self nextPlayer];
}

- (void)nextPlayer {
    [self.player replaceCurrentItemWithPlayerItem:[self getAVPlayerItem]];
    [self addAVPlayerNotification:self.player.currentItem];
}

- (void)addAVPlayerNotification:(AVPlayerItem *)playerItem {
    [playerItem addObserver:self forKeyPath:@"status" options:NSKeyValueObservingOptionNew context:nil];
    [playerItem addObserver:self forKeyPath:@"loadedTimeRanges" options:NSKeyValueObservingOptionNew context:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playbackFinished:) name:AVPlayerItemDidPlayToEndTimeNotification object:self.player.currentItem];
}

- (void)removeAVPlayerNotification {
    AVPlayerItem *playerItem = self.player.currentItem;
    [playerItem removeObserver:self forKeyPath:@"status"];
    [playerItem removeObserver:self forKeyPath:@"loadedTimeRanges"];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)stopPlayer {
    [self.player pause];
}


-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
    AVPlayerItem *playerItem = object;
    if ([keyPath isEqualToString:@"status"]) {
        AVPlayerStatus status= [[change objectForKey:@"new"] intValue];
        if (status == AVPlayerStatusReadyToPlay) {
            if (self.player.rate == 0) {
                [self.player play];
            }
            NSLog(@"playing...，video time:%.2f",CMTimeGetSeconds(playerItem.duration));
        }
    } else if([keyPath isEqualToString:@"loadedTimeRanges"]) {
        NSArray *array=playerItem.loadedTimeRanges;
        CMTimeRange timeRange = [array.firstObject CMTimeRangeValue];
        float startSeconds = CMTimeGetSeconds(timeRange.start);
        float durationSeconds = CMTimeGetSeconds(timeRange.duration);
        NSTimeInterval totalBuffer = startSeconds + durationSeconds;
        NSLog(@"totalBuffer：%.2f",totalBuffer);
    }
}

- (void)playbackFinished:(NSNotification *)notify {
    NSLog(@"video play finished");
    [self.player seekToTime:CMTimeMake(0, 1)];
    [self.player play];
}
@end
