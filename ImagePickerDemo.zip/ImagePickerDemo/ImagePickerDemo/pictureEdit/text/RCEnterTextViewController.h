//
//  RCEnterTextViewController.h
//  demo
//
//  Created by yoncn on 2018/2/8.
//  Copyright © 2018年 yoncn. All rights reserved.
//

#import <UIKit/UIKit.h>

@class RCEnterTextViewController;

@protocol RCEnterTextViewControllerDelegate <NSObject>

- (void)enterTextViewControllerDone:(RCEnterTextViewController *)textViewController text:(NSString *)text textColor:(UIColor *)textColor;

- (void)enterTextViewControllerCancel:(RCEnterTextViewController *)textViewController;

@end

@interface RCEnterTextViewController : UIViewController

//默认的文字颜色
+ (NSArray<UIColor *> *)textColorArray;

//当前的文字，默认nil。可设置初始文字。
@property (nonatomic, copy) NSString *text;

//当前选中的文字颜色下标，默认0。可设置初始下标。
@property (nonatomic) NSUInteger colorIndex;

@property (nonatomic, weak) id<RCEnterTextViewControllerDelegate> textDelegate;

@end
