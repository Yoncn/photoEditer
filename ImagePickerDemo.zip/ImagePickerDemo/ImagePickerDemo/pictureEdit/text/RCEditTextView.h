//
//  RCEditTextView.h
//  demo
//
//  Created by yoncn on 2018/2/9.
//  Copyright © 2018年 yoncn. All rights reserved.
//

#import <UIKit/UIKit.h>

@class RCEditTextView;

@protocol RCEditTextViewDelegate <NSObject>

@optional

/**
 *  @brief 开始拖动某个文字
 *  @param editTextView 当前RCEditTextView的对象
 */
- (void)editTextViewBeginDrag:(RCEditTextView *)editTextView;

/**
 *  @brief 结束拖动某个文字。
 *  @param editTextView 当前RCEditTextView的对象
 */
- (void)editTextViewEndDrag:(RCEditTextView *)editTextView;


/**
 *  @brief 双击文字，再次编辑文字的回调。完成编辑后调用 - (void)modifyText:(NSString *)text config:(void (^)(UILabel *label))configBlock; 方法来修改文字和文字颜色。取消编辑后调用 - (void)cancelEdit;方法。
 *  @param editTextView 当前RCEditTextView的对象
 *  @param label 双击的UILabel对象，可以用UILabel对象取当前的文字和文字颜色
 */
- (void)editTextView:(RCEditTextView *)editTextView clickView:(UILabel *)label;

@end

@interface RCEditTextView : UIView

@property (nonatomic, weak) id<RCEditTextViewDelegate> delegate;

//文字的编辑区域，默认 CGRectZero。
@property (nonatomic) CGRect editFrame;

/**
 *  @brief 添加新的文字
 *  @param text 输入的文字
 *  @param configBlock 可以配置UILabel对象的文字颜色等
 */
- (void)addText:(NSString *)text config:(void (^)(UILabel *label))configBlock;

/**
 *  @brief 双击文字，再次编辑文字，可用该方法来修改。
 *  @param text 输入的文字
 *  @param configBlock 可以配置UILabel对象的文字颜色等
 */
- (void)modifyText:(NSString *)text config:(void (^)(UILabel *label))configBlock;

/**
 *  @brief 双击文字，再次编辑文字，可用该方法来取消编辑。
 */
- (void)cancelEdit;

/**
 *  @brief 删除所有文字。
 */
- (void)deleteAllText;

@end
