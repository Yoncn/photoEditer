//
//  RCEnterTextViewController.m
//  demo
//
//  Created by yoncn on 2018/2/8.
//  Copyright © 2018年 yoncn. All rights reserved.
//

#import "RCEnterTextViewController.h"
#import "RCColorView.h"

#define kScreenWidth [UIScreen mainScreen].bounds.size.width
#define kScreenHeight [UIScreen mainScreen].bounds.size.height

#define kTextMaxLength 100

#define kTextColorViewHeight 60

@interface RCEnterTextViewController () <UITextViewDelegate, RCColorViewDelegate>
{
    CGFloat _keyBoardEndY;
}

@property (weak, nonatomic) IBOutlet UIView *textBackgroundView;
@property (strong, nonatomic) IBOutlet UIButton *doneButton;
@property (strong, nonatomic) IBOutlet UIButton *cancelButton;
@property (strong, nonatomic) IBOutlet UIView *topView;

@property (strong, nonatomic) UITextView *textView;

@property (strong, nonatomic) RCColorView *colorView;

@end

@implementation RCEnterTextViewController

+ (NSArray<UIColor *> *)textColorArray {
    NSArray *array = @[[UIColor colorWithRed:249.0f/255.0f green:249.0f/255.0f blue:249.0f/255.0f alpha:1],
                       [UIColor colorWithRed:0.0f/255.0f green:0.0f/255.0f blue:0.0f/255.0f alpha:1],
                       [UIColor colorWithRed:235.0f/255.0f green:65.0f/255.0f blue:37.0f/255.0f alpha:1],
                       [UIColor colorWithRed:251.0f/255.0f green:235.0f/255.0f blue:96.0f/255.0f alpha:1],
                       [UIColor colorWithRed:90.0f/255.0f green:197.0f/255.0f blue:57.0f/255.0f alpha:1],
                       [UIColor colorWithRed:75.0f/255.0f green:166.0f/255.0f blue:238.0f/255.0f alpha:1],
                       [UIColor colorWithRed:145.0f/255.0f green:28.0f/255.0f blue:246.0f/255.0f alpha:1],
                       [UIColor colorWithRed:243.0f/255.0f green:175.0f/255.0f blue:61.0f/255.0f alpha:1]
                       ];
    
    return array;
}

- (NSString *)text {
    return _textView.text;
}

- (UITextView *)textView
{
    if (!_textView) {
        _textView = [[UITextView alloc] init];
        _textView.font = [UIFont systemFontOfSize:24];
        _textView.returnKeyType = UIReturnKeyDone;
        _textView.scrollEnabled = NO;
        _textView.backgroundColor = [UIColor clearColor];
        _textView.delegate = self;
    }
    return _textView;
}

- (RCColorView *)colorView
{
    if (!_colorView) {
        NSArray *array = [RCEnterTextViewController textColorArray];
        _colorView = [[RCColorView alloc] initWithFrame:CGRectZero colors:array selected:_colorIndex];
    }
    return _colorView;
}

- (BOOL)prefersStatusBarHidden {
    return YES;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.view.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.7];
    
    [self.doneButton setTitle:@"done" forState:UIControlStateNormal];
    [self.cancelButton setTitle:@"cancel" forState:UIControlStateNormal];
    [self.doneButton setTitleColor:[UIColor greenColor] forState:UIControlStateNormal];
    
    [_textBackgroundView addSubview:self.textView];
    self.textView.text = _text;
    [self.textView becomeFirstResponder];
    
    [_textBackgroundView addSubview:self.colorView];
    self.colorView.colorDelegate = self;
    
    self.textView.textColor = self.colorView.currentColor;
    
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    [center addObserver:self selector:@selector(keybordWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [center addObserver:self selector:@selector(keybordWillHide:) name:UIKeyboardWillHideNotification object:nil];
    
    if (IS_IPHONEX) {
        self.topView.frame = CGRectMake(0, 44, self.view.bounds.size.width, 60);
        CGRect cancelFrame = self.cancelButton.frame;
        cancelFrame.origin.y = 0;
        self.cancelButton.frame = cancelFrame;
        
        CGRect okFrame = self.doneButton.frame;
        okFrame.origin.y = 0;
        self.doneButton.frame = okFrame;
    }
}

#pragma mark - NSNotification callback

- (void)keybordWillShow:(NSNotification *)notification
{
    NSDictionary *userInfo = [notification userInfo];
    NSValue *value = [userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
    _keyBoardEndY = value.CGRectValue.origin.y;
    
    NSNumber *duration = [userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey];
    [UIView animateWithDuration:duration.doubleValue animations:^{
        [UIView setAnimationBeginsFromCurrentState:YES];
        
        _textBackgroundView.frame = CGRectMake(0, self.topView.bounds.size.height + self.topView.frame.origin.y, kScreenWidth, _keyBoardEndY - self.topView.bounds.size.height - self.topView.frame.origin.y);
        
        _textView.frame = CGRectMake(0, 0, kScreenWidth, _textBackgroundView.frame.size.height - kTextColorViewHeight);
        
        _colorView.frame = CGRectMake(0, _textBackgroundView.frame.size.height - kTextColorViewHeight, kScreenWidth, kTextColorViewHeight);
    }];
}

- (void)keybordWillHide:(NSNotification *)notification
{
    NSDictionary *userInfo = [notification userInfo];
//    NSValue *value = [userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
//    CGFloat keyBoardEndY = value.CGRectValue.origin.y;
    
    NSNumber *duration = [userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey];
    
    [UIView animateWithDuration:duration.doubleValue animations:^{
    [UIView setAnimationBeginsFromCurrentState:YES];
        CGRect frame = _textBackgroundView.frame;
        frame.origin.y = kScreenHeight;
        _textBackgroundView.frame = frame;
    }];
}

#pragma mark - textView callback

-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if ([text isEqualToString:@"\n"]) { //检测到“完成”
        [self done:nil];
        return NO;
    }
    
    return YES;
}

- (void)textViewDidChange:(UITextView *)textView
{
    //字数限制最大100
    if (textView.text.length > kTextMaxLength) {
        textView.text = [textView.text substringToIndex:kTextMaxLength];
    }
    _textBackgroundView.frame = CGRectMake(0, self.topView.bounds.size.height + self.topView.frame.origin.y, kScreenWidth, _keyBoardEndY - self.topView.bounds.size.height - self.topView.frame.origin.y);
    
    _textView.frame = CGRectMake(0, 0, kScreenWidth, _textBackgroundView.frame.size.height - kTextColorViewHeight);
    
    _colorView.frame = CGRectMake(0, _textBackgroundView.frame.size.height - kTextColorViewHeight, kScreenWidth, kTextColorViewHeight);
    
}

#pragma mark - RCBrushColorView callback

- (void)colorView:(RCColorView *)brushColorView didSelectColor:(UIColor *)color;
{
    _textView.textColor = color;
    _colorIndex = [[RCEnterTextViewController textColorArray] indexOfObject:color];
}

- (IBAction)cancel:(id)sender {
    
    if (_textDelegate && [_textDelegate respondsToSelector:@selector(enterTextViewControllerCancel:)]) {
        [_textDelegate enterTextViewControllerCancel:self];
    }
    
    [_textView resignFirstResponder];
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)done:(id)sender {
    
    if (_textDelegate && [_textDelegate respondsToSelector:@selector(enterTextViewControllerDone:text:textColor:)]) {
        [_textDelegate enterTextViewControllerDone:self text:_textView.text textColor:_textView.textColor];
    }
    
    [_textView resignFirstResponder];
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
