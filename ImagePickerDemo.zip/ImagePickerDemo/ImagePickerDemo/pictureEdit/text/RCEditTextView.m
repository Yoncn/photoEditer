//
//  RCEditTextView.m
//  demo
//
//  Created by yoncn on 2018/2/9.
//  Copyright © 2018年 yoncn. All rights reserved.
//

#import "RCEditTextView.h"

@interface RCTextView : UIView

@property (nonatomic, strong, readonly) UILabel *label;

@property (nonatomic) NSUInteger margin;

- (void)sizeToFit:(CGSize)size;

@end

@implementation RCTextView

- (void)setMargin:(NSUInteger)margin {
    NSInteger value = margin - _margin;
    
    _margin = margin;
    
    self.bounds = CGRectMake(0, 0, self.bounds.size.width + value * 2, self.bounds.size.height + value * 2);
}

- (void)sizeToFit:(CGSize)size {
    
    size.width -= _margin * 2;
    size.height -= _margin * 2;
    
    CGSize fSize = [_label sizeThatFits:size];
    self.bounds = CGRectMake(0, 0, fSize.width + _margin * 2, fSize.height + _margin * 2);
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        _label = [[UILabel alloc] init];
        _label.numberOfLines = 0;
        _label.font = [UIFont systemFontOfSize:24];
        _label.textColor = [UIColor whiteColor];
        
        [self addSubview:_label];
        
        _margin = 15;
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    _label.frame = CGRectMake(_margin,
                              _margin,
                              self.bounds.size.width - _margin * 2,
                              self.bounds.size.height - _margin * 2);
    
}

@end

#define MaxSCale 6.0  //最大缩放比例
#define MinScale 0.3  //最小缩放比例

@interface RCEditTextView () <UIGestureRecognizerDelegate>

@property (nonatomic, strong) UIView *deleteView;
@property (nonatomic, strong) UIImageView *deleteImageView;

//保存RCTextView对象
@property (nonatomic, strong) NSMutableArray<RCTextView *> *array;

@property (nonatomic) NSInteger selectIndex;

@property (nonatomic) CGFloat totalScale;

@end

@implementation RCEditTextView

- (UIView *)deleteView {
    if (!_deleteView) {
        _deleteView = [[UIView alloc] init];
        _deleteView.hidden = YES;
        _deleteView.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.7];
        
        _deleteImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"text_delete"]];
        [_deleteView addSubview:_deleteImageView];
    }
    return _deleteView;
}

- (void)addText:(NSString *)text config:(void (^)(UILabel *label))configBlock {
    if (!text) {
        return;
    }
    
    RCTextView *view = [[RCTextView alloc] init];
    
    if (configBlock) {
        configBlock(view.label);
    }
    
    view.label.text = text;
    [self addSubview:view];
    [_array addObject:view];
    
    [view sizeToFit:_editFrame.size];
    view.center = self.center;
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapGesture:)];
    tapGesture.numberOfTapsRequired = 2;
    [view addGestureRecognizer:tapGesture];
    
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panGesture:)];
    [view addGestureRecognizer:pan];
    pan.delegate = self;
    
    UIPinchGestureRecognizer *pinch = [[UIPinchGestureRecognizer alloc]initWithTarget:self action:@selector(pinchGesture:)];
    [view addGestureRecognizer:pinch];
    pinch.delegate = self;
    
    UIRotationGestureRecognizer *rotation = [[UIRotationGestureRecognizer alloc] initWithTarget:self action:@selector(rotationGesture:)];
    [view addGestureRecognizer:rotation];
    rotation.delegate = self;
}

- (void)modifyText:(NSString *)text config:(void (^)(UILabel *label))configBlock {
    if (_selectIndex >= 0 && _selectIndex < _array.count) {
        RCTextView *view = [_array objectAtIndex:_selectIndex];
        
        if (configBlock) {
            configBlock(view.label);
        }
        
        CGPoint point = view.center;
        view.label.text = text;
        [view sizeToFit:_editFrame.size];
        view.center = point;
        view.hidden = NO;
        
        _selectIndex = -1;
    }
}

- (void)cancelEdit {
    if (_selectIndex >= 0 && _selectIndex < _array.count) {
        RCTextView *view = [_array objectAtIndex:_selectIndex];
        view.hidden = NO;
    }
}

- (void)deleteAllText {
    for (RCTextView *view in _array) {
        [view removeFromSuperview];
    }
    
    [_array removeAllObjects];
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self initViews];
    }
    return self;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    [self initViews];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    _deleteView.frame = CGRectMake(0, (IS_IPHONEX ? 34 : 0), CGRectGetWidth(self.bounds), 60);
    _deleteImageView.center = CGPointMake(CGRectGetWidth(_deleteView.bounds) / 2, CGRectGetHeight(_deleteView.bounds) / 2);
}

- (void)initViews {
    _editFrame = CGRectZero;
    _array = [[NSMutableArray alloc] init];
    _selectIndex = -1;
    _totalScale = 1.0;
    
    [self addSubview:self.deleteView];
}


- (BOOL)canDelete:(CGPoint)point frame:(CGRect)frame {
    BOOL delete = NO;
    if (CGRectContainsPoint(_deleteView.frame, point)) {
        delete = YES;
    } else {
        if (!CGRectIsEmpty(_editFrame) && !CGRectIsEmpty(frame)) {
            //编辑区域_editFrame和frame没有交叉
            if (!CGRectIntersectsRect(_editFrame, frame)) {
                delete = YES;
            }
        }
    }
    return delete;
}

- (void)tapGesture:(UITapGestureRecognizer *)gesture
{
    RCTextView *view = (RCTextView *)gesture.view;
    _selectIndex = [_array indexOfObject:view];
    if (_delegate && [_delegate respondsToSelector:@selector(editTextView:clickView:)]) {
        [_delegate editTextView:self clickView:view.label];
    }
    
    view.hidden = YES;
}

- (void)panGesture:(UIPanGestureRecognizer *)gesture {
    RCTextView *view = (RCTextView *)gesture.view;
    
    CGPoint point =[gesture translationInView:view];
    view.transform = CGAffineTransformTranslate(view.transform, point.x, point.y);
    [gesture setTranslation:CGPointZero inView:view];
    
    if (gesture.state == UIGestureRecognizerStateBegan) {
        _deleteView.hidden = NO;
        
        if (_delegate && [_delegate respondsToSelector:@selector(editTextViewBeginDrag:)]) {
            [_delegate editTextViewBeginDrag:self];
        }
    } else if (gesture.state == UIGestureRecognizerStateChanged) {
        CGPoint position = [gesture locationInView:self];

        
        _deleteView.backgroundColor = [self canDelete:position frame:view.frame] ? [UIColor colorWithRed:244.0/255.0 green:53.0/255.0 blue:48.0/255.0 alpha:0.7] : [[UIColor blackColor] colorWithAlphaComponent:0.7];;
        
        
    } else if (gesture.state == UIGestureRecognizerStateEnded || gesture.state == UIGestureRecognizerStateRecognized) {
        _deleteView.hidden = YES;
        
        if (_delegate && [_delegate respondsToSelector:@selector(editTextViewEndDrag:)]) {
            [_delegate editTextViewEndDrag:self];
        }
        
        CGPoint position = [gesture locationInView:self];
        if ([self canDelete:position frame:view.frame]) {
            [_array removeObject:view];
            [view removeFromSuperview];
            view = nil;
        }
    }
}

-(void)pinchGesture:(UIPinchGestureRecognizer *)gesture {
    
    CGFloat scale = gesture.scale;
    
    //放大情况
    if(scale > 1.0){
        if(_totalScale > MaxSCale) return;
    }

    //缩小情况
    if (scale < 1.0) {
        if (_totalScale < MinScale) return;
    }
    
    UIView *view = gesture.view;
    
    view.transform = CGAffineTransformScale(view.transform, scale, scale);
    gesture.scale = 1;
    
    _totalScale *= scale;
}

- (void)rotationGesture:(UIRotationGestureRecognizer *)gesture {
    UIView *view = gesture.view;

    view.transform = CGAffineTransformRotate(view.transform, gesture.rotation);
    gesture.rotation = 0;
}


- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    return YES;
}

@end
