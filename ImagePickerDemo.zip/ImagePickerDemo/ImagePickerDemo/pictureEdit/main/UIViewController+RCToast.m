//
//  UIViewController+RCToast.m
//  demo
//
//  Created by yoncn on 2018/2/23.
//  Copyright © 2018年 yoncn. All rights reserved.
//

#import "UIViewController+RCToast.h"

#define kRCToastDefaultDuration 1.0

@implementation UIViewController (RCToast)

- (UIView *)getContentViewView:(NSString *)content
{
    UIFont *font = [UIFont boldSystemFontOfSize:18];
    
    NSDictionary *dic = @{NSFontAttributeName : font};
    
    CGRect textRect = [content boundingRectWithSize:CGSizeMake(280, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingUsesFontLeading attributes:dic context:nil];
    
    UILabel *textLabel = [[UILabel alloc] initWithFrame:CGRectMake(24, 6, textRect.size.width + 12, textRect.size.height + 12)];
    textLabel.backgroundColor = [UIColor clearColor];
    textLabel.textColor = [UIColor whiteColor];
    textLabel.textAlignment = NSTextAlignmentCenter;
    textLabel.font = font;
    textLabel.text = content;
    textLabel.numberOfLines = 0;
    
    UIView *contentView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, textLabel.frame.size.width + 48, textLabel.frame.size.height + 12)];
    contentView.layer.cornerRadius = contentView.frame.size.height / 2;
    contentView.layer.borderWidth = 1.0f;
    contentView.layer.borderColor = [[UIColor grayColor] colorWithAlphaComponent:0.5].CGColor;
    contentView.backgroundColor = [UIColor colorWithRed:0.0
                                                  green:0.0f
                                                   blue:0.0f
                                                  alpha:0.7f];
    [contentView addSubview:textLabel];
    
    contentView.alpha = 0.0f;
    
    return contentView;
}

- (void)showText:(NSString *)text {
    
    [self showText:text duration:kRCToastDefaultDuration];
}

- (void)showText:(NSString *)text duration:(CGFloat)duration {
    [self showText:text duration:duration bottomOffset:self.view.window.center.y];
}

- (void)showText:(NSString *)text bottomOffset:(CGFloat)bottomOffset {
    [self showText:text duration:kRCToastDefaultDuration bottomOffset:bottomOffset];
}

- (void)showText:(NSString *)text duration:(CGFloat)duration bottomOffset:(CGFloat)bottomOffset {
    UIView *contentView = [self getContentViewView:text];
    
    UIWindow *window = self.view.window;
    CGPoint center = window.center;
    center.y = window.frame.size.height - (bottomOffset + contentView.frame.size.height / 2);
    contentView.center = center;
    [window addSubview:contentView];
    
    [self showAnimation:contentView];
    
    [self performSelector:@selector(hideAnimation:) withObject:contentView afterDelay:duration];
}

-(void)showAnimation:(UIView *)view {
    if (!view) {
        return;
    }
    
    [UIView animateWithDuration:0.3 delay:0 options:UIViewAnimationOptionCurveEaseIn animations:^{
        view.alpha = 1.0f;
    } completion:nil];
}

-(void)hideAnimation:(UIView *)view {
    if (!view) {
        return;
    }
    
    [UIView animateWithDuration:0.3 delay:0 options:UIViewAnimationOptionCurveEaseOut animations:^{
        view.alpha = 0.0f;
    } completion:^(BOOL finished) {
        [view removeFromSuperview];
    }];
}

@end
