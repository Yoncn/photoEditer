//
//  RCPictureEditViewController.m
//  demo
//
//  Created by yoncn on 2018/2/5.
//  Copyright © 2018年 yoncn. All rights reserved.
//

#import "RCPictureEditViewController.h"
#import "RCImageCropperViewController.h"
#import "RCEditTextView.h"
#import "RCEnterTextViewController.h"
#import "RCDoodleView.h"
#import "RCDoodleMoreAction.h"
#import "RCColorView.h"
#import "RCMosaicView.h"
#import "RCMosaicToolBar.h"

#import "UIImage+RCPictureEdit.h"
#import "UIViewController+RCToast.h"
#import "UIImage+Tint.h"

#define kSpace 0

typedef NS_ENUM(NSInteger, EditMode) {
    EditModeNone,
    EditModeDoodle,
    EditModeMosaic,
};

@interface RCPictureEditViewController () <RCImageCropperViewControllerDelegate, RCEnterTextViewControllerDelegate, RCEditTextViewDelegate, RCMosaicToolBarDelegate>
{
    EditMode _editMode;
    
    CGMutablePathRef _path;
    CGFloat _brushWidth;   //画笔宽度
    
    NSMutableArray *_doodleDrawCache;
    RCDoodleMoreAction *_doodleDraw;
    
    BOOL _addText; //用于标记是否增加文字
    UIColor *_prevTextColor; //记录用户上次所选颜色
}

@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UIView *editView;

@property (weak, nonatomic) IBOutlet UIView *topView;
@property (strong, nonatomic) IBOutlet UIButton *cancelButton;
@property (strong, nonatomic) IBOutlet UIButton *okButton;

@property (weak, nonatomic) IBOutlet UIView *bottomBar;
@property (weak, nonatomic) IBOutlet UIButton *doodleButton;
@property (weak, nonatomic) IBOutlet UIButton *mosaicButton;

@property (weak, nonatomic) IBOutlet UIView *toolView;
@property (weak, nonatomic) IBOutlet UIScrollView *toolScrollView;
@property (weak, nonatomic) IBOutlet UIButton *undoButton;
@property (nonatomic, strong) RCColorView *brushColorView;

@property (nonatomic, copy) UIImage *originalImage;
@property (nonatomic, strong) RCImageCropperViewController *imageCropperViewController;

@property (nonatomic, strong) RCDoodleView *doodleView; //画线的view
@property (nonatomic, strong) RCEditTextView *editTextView; //文字的view
@property (nonatomic, strong) RCMosaicView *mosaicView; //马赛克的view

@property (nonatomic, strong) RCMosaicToolBar *mosaicToolBar;
@property (strong, nonatomic) IBOutlet UIImageView *topShadow;
@property (strong, nonatomic) IBOutlet UIImageView *bottomShadow;

@end

@implementation RCPictureEditViewController

- (RCDoodleView *)doodleView {
    if (!_doodleView) {
        _doodleView = [[RCDoodleView alloc] initWithFrame:CGRectZero];
    }
    return _doodleView;
}

- (RCEditTextView *)editTextView {
    if (!_editTextView) {
        _editTextView = [[RCEditTextView alloc] initWithFrame:CGRectZero];
        _editTextView.delegate = self;
    }
    return _editTextView;
}

- (RCMosaicView *)mosaicView {
    if (!_mosaicView) {
        _mosaicView = [[RCMosaicView alloc] init];
    }
    return _mosaicView;
}

- (BOOL)prefersStatusBarHidden {
    return YES;
}

- (instancetype)initWithImage:(UIImage *)image {
    self = [super init];
    if (self) {
        
        _originalImage = [image fixOrientation];
        _editMode = EditModeNone;
        
        _brushWidth = 8;
        _doodleDrawCache = [NSMutableArray array];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    NSAssert(_originalImage, @"image is nil, init RCPictureEditViewController should use  initWithImage");
    
    _imageView.image = _originalImage;
    
    [_editView addSubview:self.mosaicView];
    self.mosaicView.image = _imageView.image;
    [_editView addSubview:self.doodleView];
    [_editView addSubview:self.editTextView];
    
    [self.cancelButton setTitle:@"cancel" forState:UIControlStateNormal];
    [self.okButton setTitle:@"done" forState:UIControlStateNormal];
    [self.okButton setTitleColor:[UIColor greenColor] forState:UIControlStateNormal];
    
    [self.doodleButton setImage:[[UIImage imageNamed:@"edit_doodle"] imageWithColor:[UIColor redColor]] forState:UIControlStateSelected];
    [self.mosaicButton setImage:[[UIImage imageNamed:@"edit_mosaic"] imageWithColor:[UIColor redColor]] forState:UIControlStateSelected];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    [self updateSubViewFrame];
    
}

#pragma mark - Public function

- (UIImage *)getEditingImage {
    return [self getSubImage];
}

#pragma mark - Button click action

- (IBAction)cancel:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

//裁剪
- (IBAction)crop:(id)sender {
    _editMode = EditModeNone;
    
    [self updateUI];
    
    RCImageCropperViewController *imageCropperViewController = [[RCImageCropperViewController alloc] initWithImage:[self getSubImage]];
    imageCropperViewController.cropDelegate = self;
    
    [self presentViewController:imageCropperViewController animated:NO completion:nil];
}

//文字
- (IBAction)text:(id)sender {
    _editMode = EditModeNone;
    [self updateUI];
    
    _addText = YES;
    _topView.hidden = YES;
    
    
    NSUInteger colorIndex = 0;
    if (_prevTextColor) {
        colorIndex = [[RCEnterTextViewController textColorArray] indexOfObject:_prevTextColor];
    }
    
    RCEnterTextViewController *vc = [[RCEnterTextViewController alloc] init];
    vc.modalPresentationStyle = UIModalPresentationOverCurrentContext;
    vc.textDelegate = self;
    vc.colorIndex = colorIndex;
    [self presentViewController:vc animated:YES completion:nil];
}

//涂鸦
- (IBAction)doodle:(id)sender {

    if (_editMode != EditModeDoodle) {
        _editMode = EditModeDoodle;
    } else {
        _editMode = EditModeNone;
    }
    
    [self updateUI];
}

- (IBAction)mosaic:(id)sender {
    if (_editMode != EditModeMosaic) {
        _editMode = EditModeMosaic;
        
        _mosaicView.image = _imageView.image;
    } else {
        _editMode = EditModeNone;
    }
    
    [self updateUI];
}

- (IBAction)undo:(id)sender {
    if (_editMode == EditModeDoodle) {
        [self undoDrawPath];
    } else if (_editMode == EditModeMosaic) {
        [_mosaicView undo];
    }
    [self updateUI];
}
- (IBAction)OK:(id)sender {
    if (_pictureEditDelegate && [_pictureEditDelegate respondsToSelector:@selector(pictureEditViewController:sendPicture:)]) {
        [_pictureEditDelegate pictureEditViewController:self sendPicture:[self getSubImage]];
    }
}


#pragma mark - RCImageCropperViewControllerDelegate

- (void)imageCropperViewControllerCancel:(RCImageCropperViewController *)imageCropperViewController {
    [imageCropperViewController dismissViewControllerAnimated:NO completion:nil];
}

- (void)imageCropperViewControllerDone:(RCImageCropperViewController *)imageCropperViewController {

    _originalImage = [imageCropperViewController getCropperImage];
    _imageView.image = _originalImage;
    [self updateSubViewFrame];
    
    //裁剪完，清除原来的文字、涂鸦、马赛克
    [_editTextView deleteAllText];
    [_doodleView clearAll];
    [_mosaicView clearAll];
    
    [_doodleDrawCache removeAllObjects];
    
    [imageCropperViewController dismissViewControllerAnimated:NO completion:nil];
}

#pragma mark - RCEnterTextViewControllerDelegate

- (void)enterTextViewControllerDone:(RCEnterTextViewController *)textViewController text:(NSString *)text textColor:(UIColor *)textColor {
    _topView.hidden = NO;
    
    if (!text || text.length == 0) {
        return;
    }
    
    //记录用户上次所选颜色
    _prevTextColor = textColor;
    
    if (_addText) {
        [_editTextView addText:text config:^(UILabel *label) {
            label.textColor = textColor;
        }];
    } else {
        [_editTextView modifyText:text config:^(UILabel *label) {
            label.textColor = textColor;
        }];
    }
}

- (void)enterTextViewControllerCancel:(RCEnterTextViewController *)textViewController {
    _topView.hidden = NO;
    [_editTextView cancelEdit];
}

#pragma mark - RCEditTextViewDelegate

- (void)editTextViewBeginDrag:(RCEditTextView *)editTextView {
    _topView.hidden = YES;
    _bottomBar.hidden = YES;
    _topShadow.hidden = YES;
    _bottomShadow.hidden = YES;
}

- (void)editTextViewEndDrag:(RCEditTextView *)editTextView {
    _topView.hidden = NO;
    _bottomBar.hidden = NO;
    _topShadow.hidden = NO;
    _bottomShadow.hidden = NO;
}

- (void)editTextView:(RCEditTextView *)editTextView clickView:(UILabel *)label {
    _addText = NO;
    
    _topView.hidden = YES;
    
    RCEnterTextViewController *vc = [[RCEnterTextViewController alloc] init];
    vc.modalPresentationStyle = UIModalPresentationOverCurrentContext;
    vc.textDelegate = self;
    vc.text = label.text;
    vc.colorIndex = [[RCEnterTextViewController textColorArray] indexOfObject:label.textColor];
    [self presentViewController:vc animated:YES completion:nil];
}

#pragma mark - RCMosaicToolBarDelegate

- (void)mosaicToolBar:(RCMosaicToolBar *)mosaicToolBar selectedIndex:(NSUInteger)selectedIndex {
    _mosaicView.currentWidth = selectedIndex;
}

#pragma mark - touch events

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {    
    if (![self needToTrack:touches withEvent:event]) return;
    NSLog(@"touchesBegan");
    
    if (_doodleDraw) {
        return;
    }
    
    NSLog(@"touchesBegan draw");
    if (_editMode == EditModeDoodle) {
        
        
        CGPoint point = [[touches anyObject] locationInView:_doodleView];
        
        if (_path) CFRelease(_path);
        _path = CGPathCreateMutable();
        
        //加起始点
        CGPathMoveToPoint(_path, NULL, point.x, point.y);
        
        _doodleDraw = [[RCDoodleMoreAction alloc] init];
        _doodleDraw.actionType = RCDoodleMoreActionDraw;
        _doodleDraw.brushColor = _brushColorView.currentColor;
        _doodleDraw.brushWidth = _brushWidth;
        NSArray *pArray = @[[NSNumber numberWithFloat:point.x], [NSNumber numberWithFloat:point.y]];
        [_doodleDraw.pathPoints addObject:pArray];
    } else if (_editMode == EditModeMosaic) {
        CGPoint point = [[touches anyObject] locationInView:_mosaicView];
        [_mosaicView draw:point firstPoint:YES];
    }
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
    if (_editMode != EditModeDoodle && _editMode != EditModeMosaic) {
        return;
    }

//    if (![self needToTrack:touches withEvent:event]) return;
    NSLog(@"touchesMoved");
    _topView.hidden = YES;
    _bottomBar.hidden = YES;
    _toolView.hidden = YES;
    _topShadow.hidden = YES;
    _bottomShadow.hidden = YES;

//    //当点不在_doodleView上，这一笔结束
//    if (!CGRectContainsPoint(_doodleView.frame, point)) {
//        [self endTrack];
//        return;
//    }

    if (_editMode == EditModeDoodle) {
        CGPoint point = [[touches anyObject] locationInView:_doodleView];
        CGPoint prevPoint = [[touches anyObject] previousLocationInView:_doodleView];
        
        if (CGPointEqualToPoint(point, prevPoint)) {
            return;
        }
        //加点
        CGPathAddQuadCurveToPoint(_path, NULL, prevPoint.x, prevPoint.y, (point.x + prevPoint.x) / 2, (point.y + prevPoint.y) / 2);
        [_doodleView drawInTempWithPath:_path lineWidth:_brushWidth lineColor:_brushColorView.currentColor];
        
        NSArray *pArray = @[[NSNumber numberWithFloat:point.x], [NSNumber numberWithFloat:point.y]];
        [_doodleDraw.pathPoints addObject:pArray];
    } else if (_editMode == EditModeMosaic) {
        CGPoint point = [[touches anyObject] locationInView:_mosaicView];
        CGPoint prevPoint = [[touches anyObject] previousLocationInView:_mosaicView];
        
        if (CGPointEqualToPoint(point, prevPoint)) {
            return;
        }
        
        [_mosaicView draw:point firstPoint:NO];
    }
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
    if (_editMode != EditModeDoodle && _editMode != EditModeMosaic) {
        return;
    }
//    if (![self needToTrack:touches withEvent:event]) return;
    NSLog(@"touchesEnded");
    
    _topView.hidden = NO;
    _bottomBar.hidden = NO;
    _toolView.hidden = NO;
    _topShadow.hidden = NO;
    _bottomShadow.hidden = NO;
    
    [self endTrack];
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    
    if (_editMode != EditModeDoodle && _editMode != EditModeMosaic) {
        return;
    }
//    if (![self needToTrack:touches withEvent:event]) return;
    NSLog(@"touchesCancelled");
    
    _bottomBar.hidden = NO;
    _toolView.hidden = NO;
    
    [self endTrack];
}

#pragma mark - private

- (void)updateSubViewFrame {
    UIImage *image = _imageView.image;
    if (!image) {
        return;
    }
    CGFloat maxWidth = self.view.bounds.size.width - kSpace * 2;
    CGFloat maxHeight = self.view.bounds.size.height - kSpace * 2 - (IS_IPHONEX ? (34+44+34*2) : 0);
    CGFloat s = maxWidth / maxHeight;
    CGFloat s1 = image.size.width / image.size.height;
    
    if (s > s1) {
        CGFloat w = maxHeight * s1;
        _imageView.frame = CGRectMake((maxWidth - w) / 2 + kSpace, kSpace + (IS_IPHONEX ? 44+34 : 0), w, maxHeight);
    } else {
        CGFloat h = maxWidth / s1;
        _imageView.frame = CGRectMake(kSpace, (maxHeight - h) / 2 + kSpace + (IS_IPHONEX ? 44+34 : 0), maxWidth, h);
    }
    
    _mosaicView.frame = _imageView.frame;
    _doodleView.frame = _imageView.frame;
    
    _editTextView.frame = _editView.bounds;
    _editTextView.editFrame = _imageView.frame;
    
    CGFloat buttonWidth = self.bottomBar.bounds.size.width/self.bottomBar.subviews.count;
    for (int i = 0; i < self.bottomBar.subviews.count; i ++) {
        UIView *subView = self.bottomBar.subviews[i];
        if ([subView isKindOfClass:[UIButton class]]) {
            subView.frame = CGRectMake(i *buttonWidth, 0, buttonWidth, self.bottomBar.bounds.size.height);
        }
    }
    
    if (IS_IPHONEX) {
        _topView.frame = CGRectMake(0, 44, self.view.bounds.size.width, 60);
        _bottomBar.frame = CGRectMake(0, self.view.bounds.size.height - 60 - 34, self.view.bounds.size.width, 60);
        _topShadow.frame = CGRectMake(0, _topView.frame.origin.y, _topView.bounds.size.width, 145);
        _bottomShadow.frame = CGRectMake(0, self.view.bounds.size.height - 145 - 34, self.view.bounds.size.width, 145);
        _toolView.frame = CGRectMake(0, _bottomBar.frame.origin.y - 60, self.view.bounds.size.width, 60);
        CGRect cancelFrame = _cancelButton.frame;
        cancelFrame.origin.y = 0;
        _cancelButton.frame = cancelFrame;
        
        CGRect okFrame = _okButton.frame;
        okFrame.origin.y = 0;
        _okButton.frame = okFrame;
    }
    
}


- (void)updateUI {

    if (_editMode == EditModeNone) {
        _toolView.hidden = YES;
        
        _doodleButton.selected = NO;
        _mosaicButton.selected = NO;
        
        _editTextView.userInteractionEnabled = YES;
    } else if (_editMode == EditModeDoodle) { //涂鸦模式
        _toolView.hidden = NO;
        
        _doodleButton.selected = YES;
        _mosaicButton.selected = NO;
        //禁止文字编辑
        _editTextView.userInteractionEnabled = NO;
        
        
        _undoButton.enabled = (_doodleDrawCache.count > 0);
        
        if (!_brushColorView) {
            _brushColorView = [[RCColorView alloc] initWithFrame:CGRectMake(0, 0, 344, 60) colors:[RCColorView defaultColors] selected:2];
            _brushColorView.spaceAuto = NO;
            [_toolScrollView addSubview:_brushColorView];
            CGSize size = _brushColorView.bounds.size;
            _toolScrollView.contentSize = size;
        }
        
        _toolScrollView.hidden = NO;
        _mosaicToolBar.hidden = YES;
        
    } else if (_editMode == EditModeMosaic) { //马赛克模式
        _toolView.hidden = NO;
        
        _mosaicButton.selected = YES;
        _doodleButton.selected = NO;
        
        //禁止文字编辑
        _editTextView.userInteractionEnabled = NO;
        
        _undoButton.enabled = [_mosaicView undoEnabled];
        
        if (!_mosaicToolBar) {
            _mosaicToolBar = [[RCMosaicToolBar alloc] initWithFrame:CGRectMake(0, 0, 248, 60)];
            _mosaicToolBar.toolDelegate = self;
            [_toolView addSubview:_mosaicToolBar];
        }

        _mosaicView.currentWidth = _mosaicToolBar.selectedIndex;
        
        _toolScrollView.hidden = YES;
        _mosaicToolBar.hidden = NO;
        
    } else {
        
    }
}

- (BOOL)needToTrack:(NSSet *)touches withEvent:(UIEvent *)event
{
    //不是画线和马赛克，不处理touch事件
    if (_editMode != EditModeDoodle && _editMode != EditModeMosaic) {
        return NO;
    }
    
//    if (event.allTouches.count > 1) return NO;

    CGPoint point = [[touches anyObject] locationInView:self.view];
    
    if (CGRectContainsPoint(_bottomBar.frame, point)) {
        return NO;
    }
    
    if (CGRectContainsPoint(_toolView.frame, point)) {
        return NO;
    }
    
    if (CGRectContainsPoint(_topView.frame, point)) {
        return NO;
    }
    
    return YES;
}

- (void)endTrack {
    if (_editMode == EditModeDoodle) {
        if (_doodleDraw) {
            if (_doodleDraw.pathPoints.count > 1) {
                [_doodleView drawInCacheWithPath:_path lineWidth:_brushWidth lineColor:_brushColorView.currentColor];
                [_doodleDrawCache addObject:_doodleDraw];
                
                [self updateUI];
            }
            _doodleDraw = nil;
            
        }
    } else if (_editMode == EditModeMosaic) {
        [_mosaicView drawEnd];
        [self updateUI];
    }
}

- (void)drawDoodle:(RCDoodleMoreAction *)doodle {
    CGMutablePathRef path = CGPathCreateMutable();
    __block CGPoint fromPoint, toPoint;
    [doodle.pathPoints enumerateObjectsUsingBlock:^(NSArray<NSNumber *> * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        CGFloat x = [[obj objectAtIndex:0] floatValue];
        CGFloat y = [[obj objectAtIndex:1] floatValue];
        if (idx == 0) {
            fromPoint = CGPointMake(x, y);
            CGPathMoveToPoint(path, NULL, fromPoint.x, fromPoint.y);
            //如果只有一个点
//            if (doodle.pathPoints.count == 1) {
//                CGPathAddQuadCurveToPoint(path, NULL, fromPoint.x, fromPoint.y, fromPoint.x, fromPoint.y);
//            }
        } else {
            toPoint = CGPointMake(x, y);
            CGPathAddQuadCurveToPoint(path, NULL, fromPoint.x, fromPoint.y, (toPoint.x + fromPoint.x) / 2, (toPoint.y + fromPoint.y) / 2);
            fromPoint = toPoint;
        }
    }];
    
    CGFloat w = doodle.brushWidth;
    if (w == 0) {
        w = _brushWidth;
    }
    
    [_doodleView drawInCacheWithPath:path lineWidth:w lineColor:doodle.brushColor];
    
    CGPathRelease(path);
}


//撤销
- (void)undoDrawPath {
    if (_doodleDrawCache.count == 0) {
        return;
    }
    
    [_doodleDrawCache removeLastObject];
    
    [_doodleView clearAll];
    
    for (RCDoodleMoreAction *doodle in _doodleDrawCache) {
        [self drawDoodle:doodle];
    }
}



- (UIImage *)getSubImage {
    CGFloat scale = _imageView.image.size.width / _imageView.bounds.size.width;
    if (scale < 3) {
        scale = 3;
    }
    
    //1.先把_editView上的文字、涂鸦和马赛克按_imageView.frame的区域截取成图片，scale提高图片清晰度
    UIImage *editImage = [UIImage cropView:_editView inRect:_imageView.frame scale:scale];
    
    //2.把editImage和_imageView.image合成一张图片
    UIImage *subImage = [editImage coverWithImage:_imageView.image];
    return subImage;
}


- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo {
    
    BOOL succeed = NO;
    if (!error) {
        [self showText:@"已保存至系统相册"];
        succeed = YES;
    } else {
        [self showText:@"保存失败"];
    }
    
    if (_pictureEditDelegate && [_pictureEditDelegate respondsToSelector:@selector(pictureEditViewController:savePicture:)]) {
        [_pictureEditDelegate pictureEditViewController:self savePicture:succeed];
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
