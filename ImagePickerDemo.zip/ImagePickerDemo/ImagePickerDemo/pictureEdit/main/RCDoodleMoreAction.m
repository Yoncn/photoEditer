//
//  RCDoodleAction.m
//  RCSDKOC
//
//  Created by yoncn on 2017/12/29.
//  Copyright © 2017年 yoncn. All rights reserved.
//

#import "RCDoodleMoreAction.h"

@interface RCDoodleMoreAction ()

@end

@implementation RCDoodleMoreAction

- (instancetype)init
{
    self = [super init];
    if (self) {
        _actionType = 0;
        _brushWidth = 0;
        _brushColor = nil;
        _pathPoints = [NSMutableArray array];
    }
    return self;
}

@end



