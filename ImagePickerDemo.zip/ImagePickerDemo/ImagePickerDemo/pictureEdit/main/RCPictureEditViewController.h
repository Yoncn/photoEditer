//
//  RCPictureEditViewController.h
//  demo
//
//  Created by yoncn on 2018/2/5.
//  Copyright © 2018年 yoncn. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class RCPictureEditViewController;

@protocol RCPictureEditDelegate <NSObject>

@optional

/**
 *  @brief 点击发送按钮的回调
 *  @param pictureEditViewController RCPictureEditViewController的对象
 *  @param image 正在编辑的图片
 */
- (void)pictureEditViewController:(RCPictureEditViewController *)pictureEditViewController sendPicture:(UIImage *)image;


/**
 *  @brief 点击保存按钮，保存图片到系统相册的回调
 *  @param pictureEditViewController RCPictureEditViewController的对象
 *  @param succeed YES 保存成功，NO 保存失败
 */
- (void)pictureEditViewController:(RCPictureEditViewController *)pictureEditViewController savePicture:(BOOL)succeed;

@end

@interface RCPictureEditViewController : UIViewController

//必须使用该初始化方法，image不能传空
- (instancetype)initWithImage:(UIImage *)image;

@property (nonatomic, weak) id<RCPictureEditDelegate> pictureEditDelegate;

//获取正在编辑的图片
- (UIImage *)getEditingImage;

@end

NS_ASSUME_NONNULL_END


