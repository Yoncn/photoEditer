//
//  RCDoodleAction.h
//  RCSDKOC
//
//  Created by yoncn on 2017/12/29.
//  Copyright © 2017年 yoncn. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, RCDoodleMoreActionType) {
    RCDoodleMoreActionDraw,          /// 画曲线
    RCDoodleMoreActionMosaic,          /// 画曲线
};

@interface RCDoodleMoreAction : NSObject


/**
 *  @brief 类型
 */
@property (nonatomic) RCDoodleMoreActionType actionType;

/**
 *  @brief 设置涂鸦轨迹或橡皮擦宽度，默认为0
 */
@property (nonatomic) float brushWidth;


/**
 *  @brief 设置涂鸦轨迹的颜色，默认为nil
 */
@property (nullable, nonatomic, copy) UIColor *brushColor;

/**
 *  @brief 涂鸦轨迹的点集合
 *  
 */
@property (nullable, nonatomic , strong) NSMutableArray *pathPoints;



@end

