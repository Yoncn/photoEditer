//
//  RCColorView.h
//  demo
//
//  Created by yoncn on 2018/2/5.
//  Copyright © 2018年 yoncn. All rights reserved.
//

#import <UIKit/UIKit.h>

@class RCColorView;

@protocol RCColorViewDelegate <NSObject>

@optional

- (void)colorView:(RCColorView *)colorView didSelectColor:(UIColor *)color;

@end

@interface RCColorView : UIView

+ (NSArray<UIColor *> *)defaultColors;

- (instancetype)initWithFrame:(CGRect)frame colors:(NSArray<UIColor *> *)colors;

- (instancetype)initWithFrame:(CGRect)frame colors:(NSArray<UIColor *> *)colors selected:(NSUInteger)selectedIndex;

@property (nonatomic, readonly, copy) UIColor *currentColor;

@property (nonatomic, weak) id<RCColorViewDelegate> colorDelegate;

@property (nonatomic) BOOL spaceAuto;
//默认12
@property (nonatomic) CGFloat buttonSpace;

//默认10
@property (nonatomic) CGFloat leftMargin;

//默认10
@property (nonatomic) CGFloat rightMargin;

@end


