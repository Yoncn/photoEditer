//
//  RCColorView.m
//  demo
//
//  Created by yoncn on 2018/2/5.
//  Copyright © 2018年 yoncn. All rights reserved.
//

#import "RCColorView.h"

#define kColorBorderWidth 2.0f

@interface RCBrushColorButton : UIControl
{
    CALayer *_colorLayer;
    CALayer *_innerLayer;
    
    CGRect _preBounds;
}

@end

@implementation RCBrushColorButton

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self configInit];
    }
    return self;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    [self configInit];
}

- (void)configInit {
    self.backgroundColor = [UIColor clearColor];
    
    _colorLayer = [CALayer layer];
    [self.layer addSublayer:_colorLayer];
    
    _innerLayer = [CALayer layer];
    _innerLayer.borderColor = [UIColor whiteColor].CGColor;
    _innerLayer.borderWidth = kColorBorderWidth;
    [self.layer addSublayer:_innerLayer];
    
    _preBounds = self.bounds;
}

#pragma mark - Override

- (void)layoutSubviews {
    [super layoutSubviews];
    if (!CGRectEqualToRect(self.bounds, _preBounds)) {
        CGFloat radius = MIN(CGRectGetWidth(self.bounds), CGRectGetHeight(self.bounds)) / 2.0f;
        _colorLayer.bounds = CGRectMake(0, 0, radius * 2.0f, radius * 2.0f);
        _colorLayer.position = CGPointMake(CGRectGetMidX(self.bounds), CGRectGetMidY(self.bounds));
        _colorLayer.cornerRadius = radius;
        _colorLayer.masksToBounds = YES;
        
        
        _innerLayer.bounds = CGRectMake(0, 0, (radius - 4) * 2.0f, (radius - 4) * 2.0f);
        _innerLayer.position = CGPointMake(CGRectGetMidX(self.bounds), CGRectGetMidY(self.bounds));
        _innerLayer.cornerRadius = radius - 4;
        _innerLayer.masksToBounds = YES;
        
        _preBounds = self.bounds;
        
        [self setNeedsDisplay];
    }
}

- (void)setSelected:(BOOL)selected {
    [super setSelected:selected];
    if (selected) {
        _colorLayer.borderWidth = kColorBorderWidth;
        _colorLayer.borderColor = [UIColor whiteColor].CGColor;
    } else {
        _colorLayer.borderWidth = 0.0;
        _colorLayer.borderColor = NULL;
    }
    
    [self setNeedsDisplay];
}

- (void)setTintColor:(UIColor *)tintColor {
    if (tintColor) {
        _innerLayer.backgroundColor = tintColor.CGColor;
    } else {
        _innerLayer.backgroundColor = NULL;
    }
}

@end


#define kButtonWidth 30

NSInteger kColorCount = 0;

@interface RCColorView () {
    NSArray *_colorArray;
    NSMutableArray *_buttonArray;
    NSInteger _selectedTag;
}

@end

@implementation RCColorView

+ (NSArray *)defaultColors
{
    return @[[UIColor colorWithRed:249.0f/255.0f green:249.0f/255.0f blue:249.0f/255.0f alpha:1],
             [UIColor colorWithRed:0.0f/255.0f green:0.0f/255.0f blue:0.0f/255.0f alpha:1],
             [UIColor colorWithRed:235.0f/255.0f green:65.0f/255.0f blue:37.0f/255.0f alpha:1],
             [UIColor colorWithRed:251.0f/255.0f green:235.0f/255.0f blue:96.0f/255.0f alpha:1],
             [UIColor colorWithRed:90.0f/255.0f green:197.0f/255.0f blue:57.0f/255.0f alpha:1],
             [UIColor colorWithRed:75.0f/255.0f green:166.0f/255.0f blue:238.0f/255.0f alpha:1],
             [UIColor colorWithRed:145.0f/255.0f green:28.0f/255.0f blue:246.0f/255.0f alpha:1],
             [UIColor colorWithRed:243.0f/255.0f green:175.0f/255.0f blue:61.0f/255.0f alpha:1]
             ];
}

- (UIColor *)currentColor {
    UIColor *color = nil;
    if (_selectedTag < _colorArray.count) {
        color = _colorArray[_selectedTag];
    }
    return color;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    NSArray *colors = [RCColorView defaultColors];
    return [self initWithFrame:frame colors:colors];
}

- (instancetype)initWithFrame:(CGRect)frame colors:(NSArray<UIColor *> *)colors
{
    return [self initWithFrame:frame colors:colors selected:0];
}

- (instancetype)initWithFrame:(CGRect)frame colors:(NSArray<UIColor *> *)colors selected:(NSUInteger)selectedIndex
{
    kColorCount = colors.count;
    NSAssert(selectedIndex < kColorCount, @"selectedIndex 必须小于colors的count");
    
    self = [super initWithFrame:frame];
    if (self) {
        _colorArray = colors;
        _selectedTag = selectedIndex;
        
        _spaceAuto = YES;
        _buttonSpace = 12;
        _leftMargin = 10;
        _rightMargin = 10;
        [self initButton];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    CGFloat viewWidth = self.bounds.size.width;
    CGFloat viewHeight = self.bounds.size.height;
    
    CGFloat space = _buttonSpace;
    
    if (_spaceAuto) {
        CGFloat w = viewWidth - _leftMargin - _rightMargin;
        if (w > kButtonWidth * _buttonArray.count) {
            space = (w - kButtonWidth * _buttonArray.count) / (_buttonArray.count - 1);
        }
    } else {
        CGRect frame = self.frame;
        frame.size.width = (kButtonWidth + space) * _buttonArray.count - space + _leftMargin + _rightMargin;
        self.frame = frame;
    }
    
    for (int i = 0; i < _buttonArray.count; i++) {
        UIButton *button = [_buttonArray objectAtIndex:i];
        CGFloat x = (kButtonWidth + space) * i + _leftMargin;
        button.frame = CGRectMake(x, (viewHeight - kButtonWidth) / 2, kButtonWidth, kButtonWidth);
    }
}

- (void)initButton {
    
    _buttonArray = [NSMutableArray arrayWithCapacity:_colorArray.count];
    
    for (int i = 0; i < _colorArray.count; i++) {
        RCBrushColorButton *button = [[RCBrushColorButton alloc] init];
        button.tag = i;
        UIColor *color = [_colorArray objectAtIndex:i];
        button.tintColor = color;
        if (i == _selectedTag) {
            button.selected = YES;
        }
        [button addTarget:self action:@selector(selectedColor:) forControlEvents:UIControlEventTouchUpInside];
        
        [self addSubview:button];
        
        [_buttonArray addObject:button];
    }
}

- (void)selectedColor:(RCBrushColorButton *)button
{
    for (UIView *view in self.subviews) {
        if ([view isKindOfClass:[RCBrushColorButton class]]) {
            RCBrushColorButton *btn = (RCBrushColorButton *)view;
            if (btn.tag == _selectedTag) {
                btn.selected = NO;
                break;
            }
        }
    }
    
    button.selected = YES;
    _selectedTag = button.tag;
    
    if (_colorDelegate && [_colorDelegate respondsToSelector:@selector(colorView:didSelectColor:)]) {
        [_colorDelegate colorView:self didSelectColor:_colorArray[button.tag]];
    }
}

- (void)setHidden:(BOOL)hidden {
    [super setHidden:hidden];
    if (hidden) {
        [self selectedColor:[self viewWithTag:_selectedTag]];
    }
}

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    UIView *target = [super hitTest:point withEvent:event];
    if (target == self) {
        CGFloat min = CGFLOAT_MAX;
        for (int i = 0; i < _colorArray.count; i ++) {
            UIView *view = [self viewWithTag:i + 1];
            CGPoint center = view.center;
            CGFloat x = fabs(point.x - center.x);
            CGFloat y = fabs(point.y - center.y);
            CGFloat distance = sqrtf(x * x - y * y);
            if (distance < min) {
                target = view;
                min = distance;
            }
        }
    }
    return target;
}

@end

