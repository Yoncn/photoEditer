//
//  RCImageCropperViewController.m
//  demo
//
//  Created by yoncn on 2018/2/5.
//  Copyright © 2018年 yoncn. All rights reserved.
//

#import "RCImageCropperViewController.h"
#import "RCCroppedView.h"

#define kSpace 9
#define kTopSpace 39
#define kBottomSpace (120+(IS_IPHONEX ? 34 : 0))

#define kRotateAnimateDuration 0.3
#define kCropAnimateDuration 0.5

@interface RCImageCropperViewController () <RCCroppedViewDelegate>
{
    int _degrees;
    BOOL _rotating;
}

@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet RCCroppedView *croppedView;
@property (weak, nonatomic) IBOutlet UIButton *resetButton;
@property (strong, nonatomic) IBOutlet UIView *bottomView;
@property (strong, nonatomic) IBOutlet UIView *toolView;

//初始图片
@property (nonatomic, copy) UIImage *originalImage;

@end

@implementation RCImageCropperViewController

- (UIImage *)getCropperImage {
    UIImageOrientation orientation;
    if (_degrees % 4 == 0) {
        orientation = UIImageOrientationUp;
    } else if (abs(_degrees % 4) == 2) {
        orientation = UIImageOrientationDown;
    } else if (_degrees % 4 == 1 || _degrees % 4 == -3) {
        orientation = UIImageOrientationRight;
    } else {
        orientation = UIImageOrientationLeft;
    }
    return [self rotateImage:_imageView.image orientation:orientation];
}

- (BOOL)prefersStatusBarHidden {
    return YES;
}

- (instancetype)initWithImage:(UIImage *)image {
    self = [super init];
    if (self) {
        _originalImage = image;
        _degrees = 0;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    _imageView.image = _originalImage;
    _croppedView.delegate = self;
    
    _resetButton.enabled = NO;
    [_resetButton setTitle:@"reset" forState:UIControlStateNormal];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    [self updateImageViewFrame];
    _croppedView.frame = _imageView.frame;
    if (IS_IPHONEX) {
        self.bottomView.frame = CGRectMake(0, self.view.bounds.size.height -  60 - 34, self.view.bounds.size.width, 60);
        self.toolView.frame = CGRectMake((self.view.bounds.size.width - 264)/2, self.bottomView.frame.origin.y -  60, 264, 60);
    }
}

#pragma mark - CroppedViewDelegate
- (void)croppedDidFinish:(RCCroppedView *)croppedView croppedFrameChanged:(BOOL)change {
    if (!change) {
        return;
    }
    
    UIImage *image = [self getSubImage];
    
    if (!image) {
        _croppedView.frame = _imageView.frame;
        return;
    }
    
    CGRect frame = _croppedView.croppedFrame;
    frame.origin.x += _imageView.frame.origin.x;
    frame.origin.y += _imageView.frame.origin.y;
    
    _imageView.image = image;
    [self rotateImageView:0 animated:NO];
    _imageView.frame = frame;
    
    _croppedView.hidden = YES;
    
    [UIView animateWithDuration:kCropAnimateDuration animations:^{
        [self updateImageViewFrame];
    } completion:^(BOOL finished) {
        _croppedView.frame = _imageView.frame;
        _croppedView.hidden = NO;
        
        _resetButton.enabled = YES;
    }];
    
}

- (IBAction)cancel:(id)sender {
    if (_cropDelegate && [_cropDelegate respondsToSelector:@selector(imageCropperViewControllerCancel:)]) {
        [_cropDelegate imageCropperViewControllerCancel:self];
    }
}

- (IBAction)confirm:(id)sender {
    if (_cropDelegate && [_cropDelegate respondsToSelector:@selector(imageCropperViewControllerDone:)]) {
        [_cropDelegate imageCropperViewControllerDone:self];
    }
}

- (IBAction)reset:(id)sender {
    _imageView.image = _originalImage;
    [self rotateImageView:0 animated:YES];
    
    _resetButton.enabled = NO;
}

- (IBAction)rotate90counterclockwise:(id)sender {
    [self rotateImageView:-1 animated:YES];
    
    _resetButton.enabled = YES;
}

- (IBAction)rotate90clockwise:(id)sender {
    [self rotateImageView:1 animated:YES];
    
    _resetButton.enabled = YES;
}

- (void)rotateImageView:(int)degrees animated:(BOOL)animated {
    if (degrees > 1 || degrees < -1) {
        return;
    }
    
    if (_rotating) {
        return;
    }
    
    _rotating = YES;
    if (degrees == 0) {
        _degrees = 0;
    } else {
        _degrees += degrees;
    }
    
    _croppedView.hidden = YES;
    if (animated) {
        
        [UIView animateWithDuration:kRotateAnimateDuration animations:^{
            CGAffineTransform transform;
            if (degrees == 0) {
                transform = CGAffineTransformMakeRotation(0);
            } else if (degrees == 1) {
                transform = CGAffineTransformRotate(_imageView.transform, M_PI_2);
            } else {
                transform = CGAffineTransformRotate(_imageView.transform, -M_PI_2);
            }
            
            _imageView.transform = transform;
            [self updateImageViewFrame];
        } completion:^(BOOL finished) {
            _rotating = NO;
            _croppedView.frame = _imageView.frame;
            _croppedView.hidden = NO;
        }];
    } else {
        CGAffineTransform transform;
        if (degrees == 0) {
            transform = CGAffineTransformMakeRotation(0);
        } else if (degrees == 1) {
            transform = CGAffineTransformRotate(_imageView.transform, M_PI_2);
        } else {
            transform = CGAffineTransformRotate(_imageView.transform, -M_PI_2);
        }
        
        _imageView.transform = transform;
        [self updateImageViewFrame];
        
        _rotating = NO;
        _croppedView.frame = _imageView.frame;
        _croppedView.hidden = NO;
    }
    
}



- (void)updateImageViewFrame {
    UIImage *image = _imageView.image;
    if (!image) {
        return;
    }
    CGFloat maxWidth = self.view.bounds.size.width - kSpace * 2;
    CGFloat maxHeight = self.view.bounds.size.height - kTopSpace - kBottomSpace;
    CGFloat s = maxWidth / maxHeight;
    CGFloat s1 = image.size.width / image.size.height;
    
    if (_degrees % 2 != 0) {
        s1 = image.size.height / image.size.width;
    }
    
    if (s > s1) {
        CGFloat w = maxHeight * s1;
        _imageView.frame = CGRectMake((maxWidth - w) / 2 + kSpace, kTopSpace, w, maxHeight);
    } else {
        CGFloat h = maxWidth / s1;
        _imageView.frame = CGRectMake(kSpace, (maxHeight - h) / 2 + kTopSpace, maxWidth, h);
    }
}

- (UIImage *)getSubImage{
    UIImage *image = _imageView.image;
    
    UIImageOrientation orientation;
    if (_degrees % 4 == 0) {
        orientation = UIImageOrientationUp;
    } else if (abs(_degrees % 4) == 2) {
        orientation = UIImageOrientationDown;
    } else if (_degrees % 4 == 1 || _degrees % 4 == -3) {
        orientation = UIImageOrientationRight;
    } else {
        orientation = UIImageOrientationLeft;
    }
    
    image = [self rotateImage:image orientation:orientation];
    
    if (!image) {
        return nil;
    }
    
    CGRect frame = _croppedView.croppedFrame;
    
    //注意view和原图大小的比例，要把_croppedView.croppedFrame按比例转换到image上的尺寸
    CGFloat scale = image.size.width / _imageView.frame.size.width;
    
    CGFloat x = frame.origin.x * scale;
    CGFloat y = frame.origin.y * scale;
    CGFloat w = frame.size.width * scale;
    CGFloat h = frame.size.height * scale;
    
    CGRect rect = CGRectMake(x, y, w, h);
    
    CGImageRef subImageRef = CGImageCreateWithImageInRect(image.CGImage, rect);

    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextDrawImage(context, rect, subImageRef);
    UIImage *subImage = [UIImage imageWithCGImage:subImageRef];
    CGImageRelease(subImageRef);
    UIGraphicsEndImageContext();
    return subImage;
}

- (UIImage *)rotateImage:(UIImage *)image orientation:(UIImageOrientation)orientation
{
    long double rotate = 0.0;
    CGRect rect;
    float translateX = 0;
    float translateY = 0;
    float scaleX = 1.0;
    float scaleY = 1.0;
    
    switch (orientation) {
        case UIImageOrientationLeft:
            rotate = M_PI_2;
            rect = CGRectMake(0, 0, image.size.height, image.size.width);
            translateX = 0;
            translateY = -rect.size.width;
            scaleY = rect.size.width / rect.size.height;
            scaleX = rect.size.height / rect.size.width;
            break;
        case UIImageOrientationRight:
            rotate = 3 * M_PI_2;
            rect = CGRectMake(0, 0, image.size.height, image.size.width);
            translateX = -rect.size.height;
            translateY = 0;
            scaleY = rect.size.width / rect.size.height;
            scaleX = rect.size.height / rect.size.width;
            break;
        case UIImageOrientationDown:
            rotate = M_PI;
            rect = CGRectMake(0, 0, image.size.width, image.size.height);
            translateX = -rect.size.width;
            translateY = -rect.size.height;
            break;
        default:
            rotate = 0.0;
            rect = CGRectMake(0, 0, image.size.width, image.size.height);
            translateX = 0;
            translateY = 0;
            break;
    }
    
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context =UIGraphicsGetCurrentContext();
    //做CTM变换
    CGContextTranslateCTM(context, 0.0, rect.size.height);
    CGContextScaleCTM(context, 1.0, -1.0);
    CGContextRotateCTM(context, rotate);
    CGContextTranslateCTM(context, translateX, translateY);
    
    CGContextScaleCTM(context, scaleX, scaleY);
    //绘制图片
    CGContextDrawImage(context, CGRectMake(0, 0, rect.size.width, rect.size.height), image.CGImage);
    
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
