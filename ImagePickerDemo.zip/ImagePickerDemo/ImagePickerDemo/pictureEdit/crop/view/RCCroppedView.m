//
//  RCCroppedView.m
//  demo
//
//  Created by yoncn on 2018/2/6.
//  Copyright © 2018年 yoncn. All rights reserved.
//

#import "RCCroppedView.h"
#import "RCSnapshotView.h"

#define space 30
#define AutoTimeInterval 0.5

#define borderWidth 20
#define borderHeight 2


typedef NS_ENUM(NSInteger, DragPosition) {
    DragPositionNone,
    DragPositionTop,
    DragPositionBottom,
    DragPositionLeft,
    DragPositionRight,
    DragPositionTopLeft,
    DragPositionTopRight,
    DragPositionBottomLeft,
    DragPositionBottomRight,
};

@interface RCCroppedBorderView : UIView

//裁剪区域
@property (nonatomic) CGRect croppedFrame;

@end

@implementation RCCroppedBorderView {
    NSMutableArray<UIView *> *_backgroundViews, *_borderViews;
}

- (void)setCroppedFrame:(CGRect)croppedFrame {
    _croppedFrame = croppedFrame;
    
    [self setNeedsLayout];
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        _backgroundViews = [NSMutableArray arrayWithCapacity:4];
        _borderViews = [NSMutableArray arrayWithCapacity:8];
        for (int i = 0; i < 4; i++) {
            UIView *view = [[UIView alloc] init];
            view.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.8];
            [self addSubview:view];
            [_backgroundViews addObject:view];
        }
        
        for (int i = 0; i < 8; i++) {
            UIView *view = [[UIView alloc] init];
            view.backgroundColor = [UIColor whiteColor];
            [self addSubview:view];
            [_borderViews addObject:view];
        }
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    CGFloat w = self.bounds.size.width;
    CGFloat h = self.bounds.size.height;
    
    for (int i = 0; i < _backgroundViews.count; i++) {
        UIView *view = _backgroundViews[i];
        if (i == 0) { //上
            view.frame = CGRectMake(0, 0, w, CGRectGetMinY(_croppedFrame));
        } else if (i == 1) { //下
            view.frame = CGRectMake(0, CGRectGetMaxY(_croppedFrame), w, h - CGRectGetMaxY(_croppedFrame));
        } else if (i == 2) { //左
            view.frame = CGRectMake(0, CGRectGetMinY(_croppedFrame), CGRectGetMinX(_croppedFrame), CGRectGetHeight(_croppedFrame));
        } else { //右
            view.frame = CGRectMake(CGRectGetMaxX(_croppedFrame), CGRectGetMinY(_croppedFrame), w - CGRectGetMaxX(_croppedFrame), CGRectGetHeight(_croppedFrame));
        }
    }
    
    for (int i = 0; i < _borderViews.count; i++) {
        UIView *view = _borderViews[i];
        if (i == 0) { //上1
            view.frame = CGRectMake(CGRectGetMinX(_croppedFrame) - borderHeight, CGRectGetMinY(_croppedFrame) - borderHeight, borderWidth, borderHeight);
        } else if (i == 1) { //上2
            view.frame = CGRectMake(CGRectGetMaxX(_croppedFrame) - borderWidth + borderHeight, CGRectGetMinY(_croppedFrame) - borderHeight, borderWidth, borderHeight);
        } else if (i == 2) { //下1
            view.frame = CGRectMake(CGRectGetMinX(_croppedFrame) - borderHeight, CGRectGetMaxY(_croppedFrame), borderWidth, borderHeight);
        } else if (i == 3) { //下2
            view.frame = CGRectMake(CGRectGetMaxX(_croppedFrame) - borderWidth + borderHeight, CGRectGetMaxY(_croppedFrame), borderWidth, borderHeight);
        } else if (i == 4) { //左1
            view.frame = CGRectMake(CGRectGetMinX(_croppedFrame) - borderHeight, CGRectGetMinY(_croppedFrame) - borderHeight, borderHeight, borderWidth);
        } else if (i == 5) { //左2
            view.frame = CGRectMake(CGRectGetMinX(_croppedFrame) - borderHeight, CGRectGetMaxY(_croppedFrame) - borderWidth + borderHeight, borderHeight, borderWidth);
        } else if (i == 6) { //右1
            view.frame = CGRectMake(CGRectGetMaxX(_croppedFrame), CGRectGetMinY(_croppedFrame) - borderHeight, borderHeight, borderWidth);
        } else if (i == 7) { //右2
            view.frame = CGRectMake(CGRectGetMaxX(_croppedFrame), CGRectGetMaxY(_croppedFrame) - borderWidth + borderHeight, borderHeight, borderWidth);
        }
        
    }
}


@end


@interface RCCroppedView ()
{
    DragPosition _currentPosition;
    NSTimer *_dragTimer;
    
    CGRect _originalFrame;
}

//中间9宫格的白色区域
@property (nonatomic, strong) RCSnapshotView *snapshotView;

//中间白色区域外的黑色区域
@property (nonatomic, strong) RCCroppedBorderView *borderView;

@end

@implementation RCCroppedView

- (RCSnapshotView *)snapshotView {
    if (!_snapshotView) {
        _snapshotView = [[RCSnapshotView alloc] initWithFrame:self.bounds];
    }
    return _snapshotView;
}

- (RCCroppedBorderView *)borderView {
    if (!_borderView) {
        _borderView = [[RCCroppedBorderView alloc] init];
    }
    return _borderView;
}

- (CGRect)croppedFrame {
    CGRect frame = _snapshotView.frame;
    
    //setFrame时改的，返回给外部时要改回去
    frame.origin.x -= space / 2;
    frame.origin.y -= space / 2;
    return frame;
}

- (void)setFrame:(CGRect)frame {
    
    //目的是为了扩大可拖动的区域。原来的_snapshotView和RCCroppedView一样大，拖动区域只能在（_snapshotView）裁剪区域边界内，不太好拖动。
    //目前修改为_snapshotView大小不变，RCCroppedView向外扩大space / 2，这样拖动区域是在_snapshotView边界内外各space / 2。
    frame.origin.x -= space / 2;
    frame.origin.y -= space / 2;
    frame.size.width += space;
    frame.size.height += space;
    
    [super setFrame:frame];

    
//    _originalFrame = self.bounds;
    
    _originalFrame = CGRectMake(space / 2, space / 2, self.bounds.size.width - space, self.bounds.size.height - space);
    
    _snapshotView.frame = _originalFrame;
    
    _borderView.frame = self.bounds;
    _borderView.croppedFrame = _originalFrame;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self initViews];
        
    }
    return self;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    [self initViews];

}

- (void)initViews {
    _minSize = CGSizeMake(50, 50);
    
    _currentPosition = DragPositionNone;
    self.backgroundColor = [UIColor clearColor];
    [self addSubview:self.snapshotView];

    [self addSubview:self.borderView];
}

#pragma mark - Touch Events

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    CGPoint point = [[touches anyObject] locationInView:self];
    _currentPosition = [self dragPosition:point];
    if (_currentPosition != DragPositionNone) {
        [self removeDragTimer];
    }
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
    if (_currentPosition == DragPositionNone) {
        return;
    }
    
    CGPoint prePoint = [[touches anyObject] previousLocationInView:self];
    CGPoint point = [[touches anyObject] locationInView:self];
    
    CGRect frame = self.snapshotView.frame;
    CGFloat offsetX = point.x - prePoint.x;
    CGFloat offsetY = point.y - prePoint.y;
    
    //根据拖动的区域改变snapshotView的frame
    switch (_currentPosition) {
        case DragPositionTop: {
            //按住顶部的拖动区域向上拖动时，裁剪区域的上边界不能小于_originalFrame的上边界
            if (frame.origin.y + offsetY < _originalFrame.origin.y) {
                offsetY = _originalFrame.origin.y - frame.origin.y;
            }
            
            //按住顶部的拖动区域向下拖动时，裁剪区域的高不能小于_minSize.height
            if (frame.size.height - offsetY < _minSize.height) {
                offsetY = frame.size.height - _minSize.height;
            }
            
            frame.origin.y += offsetY;
            frame.size.height -= offsetY;
            break;
        }
        case DragPositionBottom: {
            //按住底部的拖动区域向下拖动时，裁剪区域的下边界不能大于_originalFrame的下边界
            if (CGRectGetMaxY(frame) + offsetY > CGRectGetMaxY(_originalFrame)) {
                offsetY = CGRectGetMaxY(_originalFrame) - CGRectGetMaxY(frame);
            }
            
            //按住底部的拖动区域向上拖动时，裁剪区域的高不能小于_minSize.height
            if (frame.size.height + offsetY < _minSize.height) {
                offsetY = _minSize.height - frame.size.height;
            }
            frame.size.height += offsetY;
            break;
        }
        case DragPositionLeft: {
            //按住左边的拖动区域向左拖动时，裁剪区域的左边界不能小于_originalFrame的左边界
            if (frame.origin.x + offsetX < _originalFrame.origin.x) {
                offsetX = _originalFrame.origin.x - frame.origin.x;
            }
            
            //按住左边的拖动区域向右拖动时，裁剪区域的宽不能小于_minSize.width
            if (frame.size.width - offsetX < _minSize.width) {
                offsetX = frame.size.width - _minSize.width;
            }
            
            frame.origin.x += offsetX;
            frame.size.width -= offsetX;
            break;
        }
        case DragPositionRight: {
            //按住右边的拖动区域向右拖动时，裁剪区域的左右边界不能大于_originalFrame的右边界
            if (CGRectGetMaxX(frame) + offsetX > CGRectGetMaxX(_originalFrame)) {
                offsetX = CGRectGetMaxX(_originalFrame) - CGRectGetMaxX(frame);
            }
            
            //按住右边的拖动区域向左拖动时，裁剪区域的宽不能小于_minSize.width
            if (frame.size.width + offsetX < _minSize.width) {
                offsetX = _minSize.width - frame.size.width;
            }
            frame.size.width += offsetX;
            break;
        }
        case DragPositionTopLeft: {
            //按住左上角的拖动区域向左拖动时，裁剪区域的左边界不能小于_originalFrame的左边界
            if (frame.origin.x + offsetX < _originalFrame.origin.x) {
                offsetX = _originalFrame.origin.x - frame.origin.x;
            }
            
            //按住左上角的拖动区域向右拖动时，裁剪区域的宽不能小于_minSize.width
            if (frame.size.width - offsetX < _minSize.width) {
                offsetX = frame.size.width - _minSize.width;
            }
            
            //按住左上角的拖动区域向上拖动时，裁剪区域的上边界不能小于_originalFrame的上边界
            if (frame.origin.y + offsetY < _originalFrame.origin.y) {
                offsetY = _originalFrame.origin.y - frame.origin.y;
            }
            
            //按住左上角的拖动区域向下拖动时，裁剪区域的高不能小于_minSize.height
            if (frame.size.height - offsetY < _minSize.height) {
                offsetY = frame.size.height - _minSize.height;
            }
            
            frame.origin.x += offsetX;
            frame.size.width -= offsetX;
            frame.origin.y += offsetY;
            frame.size.height -= offsetY;
            break;
        }
        case DragPositionTopRight: {
            //按住右上角的拖动区域向右拖动时，裁剪区域的右边界不能大于_originalFrame的右边界
            if (CGRectGetMaxX(frame) + offsetX > CGRectGetMaxX(_originalFrame)) {
                offsetX = CGRectGetMaxX(_originalFrame) - CGRectGetMaxX(frame);
            }
            
            //按住右上角的拖动区域向左拖动时，裁剪区域的宽不能小于_minSize.width
            if (frame.size.width + offsetX < _minSize.width) {
                offsetX = _minSize.width - frame.size.width;
            }
            
            //按住右上角的拖动区域向上拖动时，裁剪区域的上边界不能小于_originalFrame的上边界
            if (frame.origin.y + offsetY < _originalFrame.origin.y) {
                offsetY = _originalFrame.origin.y - frame.origin.y;
            }
            
            //按住右上角的拖动区域向下拖动时，裁剪区域的高不能小于_minSize.height
            if (frame.size.height - offsetY < _minSize.height) {
                offsetY = frame.size.height - _minSize.height;
            }
            
            frame.size.width += offsetX;
            
            frame.origin.y += offsetY;
            frame.size.height -= offsetY;
            break;
        }
        case DragPositionBottomLeft: {
            //按住左下角的拖动区域向左拖动时，裁剪区域的左边界不能小于_originalFrame的左边界
            if (frame.origin.x + offsetX < _originalFrame.origin.x) {
                offsetX = _originalFrame.origin.x - frame.origin.x;
            }
            
            //按住左下角的拖动区域向右拖动时，裁剪区域的宽不能小于_minSize.width
            if (frame.size.width - offsetX < _minSize.width) {
                offsetX = frame.size.width - _minSize.width;
            }
            
            //按住左下角的拖动区域向下拖动时，裁剪区域的下边界不能大于_originalFrame的下边界
            if (CGRectGetMaxY(frame) + offsetY > CGRectGetMaxY(_originalFrame)) {
                offsetY = CGRectGetMaxY(_originalFrame) - CGRectGetMaxY(frame);
            }
            
            //按住左下角的拖动区域向上拖动时，裁剪区域的高不能小于_minSize.height
            if (frame.size.height + offsetY < _minSize.height) {
                offsetY = _minSize.height - frame.size.height;
            }
            
            frame.origin.x += offsetX;
            frame.size.width -= offsetX;
            
            frame.size.height += offsetY;
            break;
        }
        case DragPositionBottomRight: {
            //按住右下角的拖动区域向右拖动时，裁剪区域的右边界不能大于_originalFrame的右边界
            if (CGRectGetMaxX(frame) + offsetX > CGRectGetMaxX(_originalFrame)) {
                offsetX = CGRectGetMaxX(_originalFrame) - CGRectGetMaxX(frame);
            }
            
            //按住右下角的拖动区域向左拖动时，裁剪区域的宽不能小于_minSize.width
            if (frame.size.width + offsetX < _minSize.width) {
                offsetX = _minSize.width - frame.size.width;
            }
            
            //按住右下角的拖动区域向下拖动时，裁剪区域的下边界不能大于_originalFrame的下边界
            if (CGRectGetMaxY(frame) + offsetY > CGRectGetMaxY(_originalFrame)) {
                offsetY = CGRectGetMaxY(_originalFrame) - CGRectGetMaxY(frame);
            }
            
            //按住右下角的拖动区域向上拖动时，裁剪区域的高不能小于_minSize.height
            if (frame.size.height + offsetY < _minSize.height) {
                offsetY = _minSize.height - frame.size.height;
            }
            
            frame.size.width += offsetX;
            frame.size.height += offsetY;
            break;
        }
        default:
            break;
    }
    
    _snapshotView.frame = frame;

    _borderView.croppedFrame = frame;
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
    if (_currentPosition != DragPositionNone) {
        [self createDragTimer];
    }
    
    _currentPosition = DragPositionNone;
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    if (_currentPosition != DragPositionNone) {
        [self createDragTimer];
    }
    
    _currentPosition = DragPositionNone;
}

- (DragPosition)dragPosition:(CGPoint)point {
    CGFloat minX = CGRectGetMinX(self.snapshotView.frame);
    CGFloat minY = CGRectGetMinY(self.snapshotView.frame);
    CGFloat maxX = CGRectGetMaxX(self.snapshotView.frame);
    CGFloat maxY = CGRectGetMaxY(self.snapshotView.frame);
    CGFloat w = CGRectGetWidth(self.snapshotView.frame);
    CGFloat h = CGRectGetHeight(self.snapshotView.frame);
    
    //原来可拖动的区域是以snapshotView.frame为边界，向内 space 的距离。不太好拖动
    //现在改为以snapshotView.frame为边界，向外向内各space / 2 的距离。
    
//    CGRect top = CGRectMake(minX + space, minY, w - space * 2, space);
    CGRect top = CGRectMake(minX + space / 2, minY - space / 2, w - space, space);
    if (CGRectContainsPoint(top, point)) {
        return DragPositionTop;
    }
    
//    CGRect bottom = CGRectMake(minX + space, maxY - space, w - space * 2, space);
    CGRect bottom = CGRectMake(minX + space / 2, maxY - space / 2, w - space, space);
    if (CGRectContainsPoint(bottom, point)) {
        return DragPositionBottom;
    }
    
//    CGRect left = CGRectMake(minX, minY + space, space, h - space * 2);
    CGRect left = CGRectMake(minX - space / 2, minY + space / 2, space, h - space);
    if (CGRectContainsPoint(left, point)) {
        return DragPositionLeft;
    }
    
//    CGRect right = CGRectMake(maxX - space, minY + space, space, h - space * 2);
    CGRect right = CGRectMake(maxX - space / 2, minY + space / 2, space, h - space);
    if (CGRectContainsPoint(right, point)) {
        return DragPositionRight;
    }
    
//    CGRect topLeft = CGRectMake(minX, minY, space, space);
    CGRect topLeft = CGRectMake(minX - space / 2, minY - space / 2, space, space);
    if (CGRectContainsPoint(topLeft, point)) {
        return DragPositionTopLeft;
    }
    
//    CGRect topRight = CGRectMake(maxX - space, minY, space, space);
    CGRect topRight = CGRectMake(maxX - space / 2, minY - space / 2, space, space);
    if (CGRectContainsPoint(topRight, point)) {
        return DragPositionTopRight;
    }
    
//    CGRect bottomLeft = CGRectMake(minX, maxY - space, space, space);
    CGRect bottomLeft = CGRectMake(minX - space / 2, maxY - space / 2, space, space);
    if (CGRectContainsPoint(bottomLeft, point)) {
        return DragPositionBottomLeft;
    }
    
    CGRect bottomRight = CGRectMake(maxX - space / 2, maxY - space / 2, space, space);
    if (CGRectContainsPoint(bottomRight, point)) {
        return DragPositionBottomRight;
    }
    
    return DragPositionNone;
}

- (void)removeDragTimer {
    if (!_dragTimer) {
        return;
    }
    
    [_dragTimer invalidate];
    _dragTimer = nil;
}

- (void)createDragTimer {
    if (_dragTimer) {
        return;
    }
    
    _dragTimer = [NSTimer timerWithTimeInterval:AutoTimeInterval target:self selector:@selector(dragTimerFired) userInfo:nil repeats:NO];
    
    [[NSRunLoop mainRunLoop] addTimer:_dragTimer forMode:NSRunLoopCommonModes];
}

- (void)dragTimerFired {
    [self removeDragTimer];
    
    if (_delegate && [_delegate respondsToSelector:@selector(croppedDidFinish:croppedFrameChanged:)]) {
        [_delegate croppedDidFinish:self croppedFrameChanged:!CGRectEqualToRect(_originalFrame, _snapshotView.frame)];
    }
}

@end
