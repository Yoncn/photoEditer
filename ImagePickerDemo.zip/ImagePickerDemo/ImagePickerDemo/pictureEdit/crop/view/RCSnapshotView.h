//
//  RCSnapshotView.h
//  demo
//
//  Created by yoncn on 2018/2/7.
//  Copyright © 2018年 yoncn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RCSnapshotView : UIView

@end
