//
//  RCCroppedView.h
//  demo
//
//  Created by yoncn on 2018/2/6.
//  Copyright © 2018年 yoncn. All rights reserved.
//

#import <UIKit/UIKit.h>

@class RCCroppedView;

@protocol RCCroppedViewDelegate <NSObject>

- (void)croppedDidFinish:(RCCroppedView *)croppedView croppedFrameChanged:(BOOL)change;

@end

@interface RCCroppedView : UIView

@property (nonatomic, weak) id<RCCroppedViewDelegate> delegate;

//缩放时，能够缩小到最小size。默认(50, 50)
@property (nonatomic) CGSize minSize;

//裁剪区域
@property (nonatomic, readonly) CGRect croppedFrame;

@end
