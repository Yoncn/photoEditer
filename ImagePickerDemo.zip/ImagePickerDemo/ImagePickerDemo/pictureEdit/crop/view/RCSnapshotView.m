//
//  RCSnapshotView.m
//  demo
//
//  Created by yoncn on 2018/2/7.
//  Copyright © 2018年 yoncn. All rights reserved.
//

#import "RCSnapshotView.h"

#define lineWidth 1

@interface RCSnapshotView ()

@property (nonatomic, strong) UIView *horizontalLine1;
@property (nonatomic, strong) UIView *horizontalLine2;

@property (nonatomic, strong) UIView *verticalLine1;
@property (nonatomic, strong) UIView *verticalLine2;

@end

@implementation RCSnapshotView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self initViews];
        
    }
    return self;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    [self initViews];
    
}

- (void)initViews {
    
    self.backgroundColor = [UIColor clearColor];
    self.layer.borderColor = [UIColor whiteColor].CGColor;
    self.layer.borderWidth = lineWidth;
    
    _horizontalLine1 = [[UIView alloc] init];
    _horizontalLine1.backgroundColor = [UIColor whiteColor];
    [self addSubview:_horizontalLine1];
    
    _horizontalLine2 = [[UIView alloc] init];
    _horizontalLine2.backgroundColor = [UIColor whiteColor];
    [self addSubview:_horizontalLine2];
    
    _verticalLine1 = [[UIView alloc] init];
    _verticalLine1.backgroundColor = [UIColor whiteColor];
    [self addSubview:_verticalLine1];
    
    _verticalLine2 = [[UIView alloc] init];
    _verticalLine2.backgroundColor = [UIColor whiteColor];
    [self addSubview:_verticalLine2];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    CGFloat w = CGRectGetWidth(self.bounds);
    CGFloat h = CGRectGetHeight(self.bounds);
    
    _horizontalLine1.frame = CGRectMake(0, h / 3, w, lineWidth);
    _horizontalLine2.frame = CGRectMake(0, h * 2 / 3, w, lineWidth);
    
    _verticalLine1.frame = CGRectMake(w / 3, 0, lineWidth, h);
    _verticalLine2.frame = CGRectMake(w * 2 / 3, 0, lineWidth, h);
}

@end
