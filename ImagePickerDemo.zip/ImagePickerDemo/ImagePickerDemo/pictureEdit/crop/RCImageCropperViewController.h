//
//  RCImageCropperViewController.h
//  demo
//
//  Created by yoncn on 2018/2/5.
//  Copyright © 2018年 yoncn. All rights reserved.
//

#import <UIKit/UIKit.h>

@class RCImageCropperViewController;

@protocol RCImageCropperViewControllerDelegate <NSObject>

- (void)imageCropperViewControllerDone:(RCImageCropperViewController *)imageCropperViewController;

- (void)imageCropperViewControllerCancel:(RCImageCropperViewController *)imageCropperViewController;

@end

@interface RCImageCropperViewController : UIViewController

@property (nonatomic, weak) id<RCImageCropperViewControllerDelegate> cropDelegate;

- (instancetype)initWithImage:(UIImage *)image;

- (UIImage *)getCropperImage;

@end
