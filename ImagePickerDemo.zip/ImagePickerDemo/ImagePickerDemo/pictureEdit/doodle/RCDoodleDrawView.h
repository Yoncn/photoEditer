//
//  DoodleDrawView.h
//  UltimateShow
//
//  Created by yoncn on 17/1/4.
//  Copyright © 2017年 yoncn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RCDoodleDrawView : UIView

- (void)drawInCacheWithPath:(CGPathRef)path width:(CGFloat)width color:(UIColor *)color;
- (void)drawInTempWithPath:(CGPathRef)path width:(CGFloat)width color:(UIColor *)color;
- (void)eraseInCacheWithPath:(CGPathRef)path width:(CGFloat)width;
- (void)clearAll;

- (void)drawImage:(UIImage *)image rect:(CGRect)rect;

@end
