//
//  DoodleDrawView.m
//  UltimateShow
//
//  Created by yoncn on 17/1/4.
//  Copyright © 2017年 yoncn. All rights reserved.
//

#import "RCDoodleDrawView.h"

@interface RCDoodleDrawView ()

@property (nonatomic, strong) UIImage *cacheImage;

@end

@implementation RCDoodleDrawView

- (void)drawRect:(CGRect)rect
{
    if (_cacheImage) {
        [_cacheImage drawInRect:self.bounds];
    }
}

- (void)drawInCacheWithPath:(CGPathRef)path width:(CGFloat)width color:(UIColor *)color
{
    UIGraphicsBeginImageContextWithOptions(self.bounds.size, NO, 0.0);
    [_cacheImage drawInRect:self.bounds];
    
    CGContextSetLineCap(UIGraphicsGetCurrentContext(), kCGLineCapRound);
    CGContextSetLineJoin(UIGraphicsGetCurrentContext(), kCGLineJoinRound);
    CGContextSetStrokeColorWithColor(UIGraphicsGetCurrentContext(), color.CGColor);
    CGContextSetLineWidth(UIGraphicsGetCurrentContext(), width);
    CGContextBeginPath(UIGraphicsGetCurrentContext());
    CGContextAddPath(UIGraphicsGetCurrentContext(), path);
    
    CGContextStrokePath(UIGraphicsGetCurrentContext());
    _cacheImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    [self setNeedsDisplay];
}

- (void)drawInTempWithPath:(CGPathRef)path width:(CGFloat)width color:(UIColor *)color
{
    if (_cacheImage) {
        _cacheImage = nil;
    }
    
    [self drawInCacheWithPath:path width:width color:color];
}

- (void)eraseInCacheWithPath:(CGPathRef)path width:(CGFloat)width
{
    UIGraphicsBeginImageContextWithOptions(self.bounds.size, NO, 0.0);
    [_cacheImage drawInRect:self.bounds];
    
    CGContextSetBlendMode(UIGraphicsGetCurrentContext(), kCGBlendModeClear);
    CGContextSetLineCap(UIGraphicsGetCurrentContext(), kCGLineCapRound);
    CGContextSetLineJoin(UIGraphicsGetCurrentContext(), kCGLineJoinRound);
    CGContextSetLineWidth(UIGraphicsGetCurrentContext(), width);
    CGContextBeginPath(UIGraphicsGetCurrentContext());
    CGContextAddPath(UIGraphicsGetCurrentContext(), path);
    
    CGContextStrokePath(UIGraphicsGetCurrentContext());
    _cacheImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    [self setNeedsDisplay];
}

- (void)clearAll
{
    if (_cacheImage) {
        _cacheImage = nil;
    }
    
    [self setNeedsDisplay];
}

- (void)drawImage:(UIImage *)image rect:(CGRect)rect {
    
    
    UIGraphicsBeginImageContextWithOptions(self.bounds.size, NO, [UIScreen mainScreen].scale);
    [_cacheImage drawInRect:self.bounds];
    
    [image drawInRect:rect];
    
    _cacheImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    [self setNeedsDisplay];
}

@end
