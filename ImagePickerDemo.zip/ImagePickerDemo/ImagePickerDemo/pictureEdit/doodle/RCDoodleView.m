//
//  DoodleView.m
//  UltimateShow
//
//  Created by yoncn on 17/1/4.
//  Copyright © 2017年 yoncn. All rights reserved.
//

#import "RCDoodleView.h"
#import "RCDoodleDrawView.h"

@interface RCDoodleView ()

@property (nonatomic, strong) UIImageView *backgroundView;
//缓存轨迹的画布
@property (nonatomic, strong) RCDoodleDrawView *cacheCanvas;

@property (nonatomic, strong) NSMutableArray<RCDoodleDrawView *> *tempCanvasArray;

@end

@implementation RCDoodleView

- (UIImageView *)backgroundView
{
    if (!_backgroundView) {
        _backgroundView = [[UIImageView alloc] init];
        _backgroundView.backgroundColor = [UIColor clearColor];
        _backgroundView.contentMode = UIViewContentModeScaleAspectFit;
        if (_backgroundImage) {
            _backgroundView.image = _backgroundImage;
        }
    }
    return _backgroundView;
}

- (RCDoodleDrawView *)cacheCanvas
{
    if (!_cacheCanvas) {
        _cacheCanvas = [[RCDoodleDrawView alloc] init];
        _cacheCanvas.backgroundColor = [UIColor clearColor];
    }
    return _cacheCanvas;
}

- (NSUInteger)tempCanvasCount {
    return _tempCanvasArray.count;
}

- (void)setTempCanvasCount:(NSUInteger)tempCanvasCount {
    NSInteger count = tempCanvasCount - _tempCanvasArray.count;
    
    for (int i = 0; i < count; i++) {
        RCDoodleDrawView *tempCanvas = [[RCDoodleDrawView alloc] init];
        tempCanvas.backgroundColor = [UIColor clearColor];
        [self addSubview:tempCanvas];
        [_tempCanvasArray addObject:tempCanvas];
    }
}

- (void)setBackgroundImage:(UIImage *)backgroundImage
{
    if (_backgroundImage != backgroundImage) {
        _backgroundImage = backgroundImage;
        if (_backgroundView) {
            _backgroundView.image = backgroundImage;
        }
    }
}

- (instancetype)initWithFrame:(CGRect)frame image:(UIImage *)image
{
    self = [super initWithFrame:frame];
    if (self) {
        _backgroundImage = image;
        _tempCanvasArray = [NSMutableArray array];
        
        [self initViews];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    return [self initWithFrame:frame image:nil];
}

- (void)awakeFromNib
{
    [super awakeFromNib];
    
    [self initViews];
}

- (void)layoutSubviews
{
    if (_backgroundView) {
        _backgroundView.frame = self.bounds;
    }
    
    if (_cacheCanvas) {
        _cacheCanvas.frame = self.bounds;
    }
    
    for (RCDoodleDrawView *tempCanvas in _tempCanvasArray) {
        tempCanvas.frame = self.bounds;
    }
}

- (void)initViews
{
    [self addSubview:self.backgroundView];
    [self addSubview:self.cacheCanvas];
    
    RCDoodleDrawView *tempCanvas = [[RCDoodleDrawView alloc] init];
    tempCanvas.backgroundColor = [UIColor clearColor];
    [self addSubview:tempCanvas];
    [_tempCanvasArray addObject:tempCanvas];
}

- (void)drawInCacheWithPath:(CGPathRef)path lineWidth:(CGFloat)width lineColor:(UIColor *)color
{
    [self drawInCacheWithPath:path lineWidth:width lineColor:color index:0];
}

- (void)drawInTempWithPath:(CGPathRef)path lineWidth:(CGFloat)width lineColor:(UIColor *)color
{
    [self drawInTempWithPath:path lineWidth:width lineColor:color index:0];
}

- (void)eraseInCacheWithPath:(CGPathRef)path lineWidth:(CGFloat)width
{
    if (_cacheCanvas) {
        [_cacheCanvas eraseInCacheWithPath:path width:width];
    }
}

- (void)clearAll
{
    if (_cacheCanvas) {
        [_cacheCanvas clearAll];
    }
    
    for (RCDoodleDrawView *tempCanvas in _tempCanvasArray) {
        [tempCanvas clearAll];
    }
}

- (void)drawImageInCache:(UIImage *)image rect:(CGRect)rect orientation:(DrawImageRotateAngle)orientation {
    UIImage *newImage = nil;
    switch (orientation) {
        case DrawImageRotateAngleM_PI_2:
            newImage = [UIImage imageWithCGImage:image.CGImage scale:image.scale orientation:UIImageOrientationRight];
            break;
        case DrawImageRotateAngle_3_M_PI_2:
            newImage = [UIImage imageWithCGImage:image.CGImage scale:image.scale orientation:UIImageOrientationLeft];
            break;
        case DrawImageRotateAngleM_PI:
            newImage = [UIImage imageWithCGImage:image.CGImage scale:image.scale orientation:UIImageOrientationDown];
            break;
        default:
            newImage = image;
            break;
    }
    [_cacheCanvas drawImage:newImage rect:rect];
}

- (UIImage *)convertViewToImage {
    CGSize size = self.bounds.size;
    UIGraphicsBeginImageContextWithOptions(size, NO, [UIScreen mainScreen].scale);
    CGRect rec = CGRectMake(0, 0, size.width, size.height);
    [self drawViewHierarchyInRect:rec afterScreenUpdates:YES];
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

- (void)drawInCacheWithPath:(CGPathRef)path lineWidth:(CGFloat)width lineColor:(UIColor *)color index:(NSUInteger)index
{
    RCDoodleDrawView *tempCanvas = [self getTempCanvas:index];
    if (tempCanvas) {
        [tempCanvas clearAll];
    }
    
    if (_cacheCanvas) {
        [_cacheCanvas drawInCacheWithPath:path width:width color:color];
    }
}

- (void)drawInTempWithPath:(CGPathRef)path lineWidth:(CGFloat)width lineColor:(UIColor *)color index:(NSUInteger)index
{
    RCDoodleDrawView *tempCanvas = [self getTempCanvas:index];
    if (tempCanvas) {
        [tempCanvas drawInTempWithPath:path width:width color:color];
    }
}

- (RCDoodleDrawView *)getTempCanvas:(NSUInteger)index {
    RCDoodleDrawView *canvas;
    if (index < _tempCanvasArray.count) {
        canvas = _tempCanvasArray[index];
    }
    return canvas;
}
@end
