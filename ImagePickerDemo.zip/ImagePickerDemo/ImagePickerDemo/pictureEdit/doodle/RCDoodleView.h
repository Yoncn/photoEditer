//
//  DoodleView.h
//  UltimateShow
//
//  Created by yoncn on 17/1/4.
//  Copyright © 2017年 yoncn. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum {
    DrawImageRotateAngle0,
    DrawImageRotateAngleM_PI_2,
    DrawImageRotateAngleM_PI,
    DrawImageRotateAngle_3_M_PI_2
} DrawImageRotateAngle;

@interface RCDoodleView : UIView

@property (nonatomic, strong) UIImage *backgroundImage;

- (instancetype)initWithFrame:(CGRect)frame image:(UIImage *)image;

//设置多层临时画布，默认1
@property (nonatomic) NSUInteger tempCanvasCount;

//画到缓存的画布上
- (void)drawInCacheWithPath:(CGPathRef)path lineWidth:(CGFloat)width lineColor:(UIColor *)color;

//画到临时的画布上
- (void)drawInTempWithPath:(CGPathRef)path lineWidth:(CGFloat)width lineColor:(UIColor *)color;

- (void)eraseInCacheWithPath:(CGPathRef)path lineWidth:(CGFloat)width;
- (void)clearAll;


- (void)drawImageInCache:(UIImage *)image rect:(CGRect)rect orientation:(DrawImageRotateAngle)orientation;

- (UIImage *)convertViewToImage;


//这两个接口适用于多层画布
- (void)drawInCacheWithPath:(CGPathRef)path lineWidth:(CGFloat)width lineColor:(UIColor *)color index:(NSUInteger)index;;
- (void)drawInTempWithPath:(CGPathRef)path lineWidth:(CGFloat)width lineColor:(UIColor *)color index:(NSUInteger)index;

@end
