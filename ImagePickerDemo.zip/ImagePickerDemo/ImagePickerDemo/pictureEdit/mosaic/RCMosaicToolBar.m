//
//  RCMosaicToolBar.m
//  demo
//
//  Created by yoncn on 2018/3/14.
//  Copyright © 2018年 yoncn. All rights reserved.
//

#import "RCMosaicToolBar.h"

@interface CustomToolButton : UIControl
{
    CALayer *_colorLayer;
    CALayer *_innerLayer;
    
    CGRect _preBounds;
}

@end

@implementation CustomToolButton

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self configInit];
    }
    return self;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    [self configInit];
}

- (void)configInit {
    self.backgroundColor = [UIColor clearColor];
    
    _colorLayer = [CALayer layer];
    [self.layer addSublayer:_colorLayer];
    
    _innerLayer = [CALayer layer];
    _innerLayer.backgroundColor = [UIColor whiteColor].CGColor;
    [self.layer addSublayer:_innerLayer];
    
    _preBounds = self.bounds;
}

#pragma mark - Override

- (void)layoutSubviews {
    [super layoutSubviews];
    if (!CGRectEqualToRect(self.bounds, _preBounds)) {
        CGFloat radius = MIN(CGRectGetWidth(self.bounds), CGRectGetHeight(self.bounds)) / 2.0f;
        _colorLayer.bounds = CGRectMake(0, 0, radius * 2.0f, radius * 2.0f);
        _colorLayer.position = CGPointMake(CGRectGetMidX(self.bounds), CGRectGetMidY(self.bounds));
        _colorLayer.cornerRadius = radius;
        _colorLayer.masksToBounds = YES;
        
        
        _innerLayer.bounds = CGRectMake(0, 0, (radius - 4) * 2.0f, (radius - 4) * 2.0f);
        _innerLayer.position = CGPointMake(CGRectGetMidX(self.bounds), CGRectGetMidY(self.bounds));
        _innerLayer.cornerRadius = radius - 4;
        _innerLayer.masksToBounds = YES;
        
        _preBounds = self.bounds;
        
        [self setNeedsDisplay];
    }
}

- (void)setSelected:(BOOL)selected {
    [super setSelected:selected];
    if (selected) {
        _colorLayer.borderWidth = 2;
        _colorLayer.borderColor = [UIColor redColor].CGColor;
    } else {
        _colorLayer.borderWidth = 0;
        _colorLayer.borderColor = NULL;
    }
    
    [self setNeedsDisplay];
}

- (void)setTintColor:(UIColor *)tintColor {
    if (tintColor) {
        _innerLayer.backgroundColor = tintColor.CGColor;
    } else {
        _innerLayer.backgroundColor = NULL;
    }
}

@end

#define kButtonCount 5

//按钮最小22，在按4递增
#define kMinButtonWdith 22

#define kButtonSpace 18

@interface RCMosaicToolBar () {
    NSMutableArray *_buttonArray;
}

@end

@implementation RCMosaicToolBar

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        _selectedIndex = 2;
        [self initButton];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    CGFloat viewHeight = self.bounds.size.height;
    
    CGFloat space = kButtonSpace;
    
    for (int i = 0; i < _buttonArray.count; i++) {
        UIButton *button = [_buttonArray objectAtIndex:i];
        CGFloat buttonWidth = kMinButtonWdith + i * 4;
        CGFloat x = 20 + (kMinButtonWdith + space) * i + (0 + i * 4) * (i - 1) / 2;
        button.frame = CGRectMake(x, (viewHeight - buttonWidth) / 2, buttonWidth, buttonWidth);
    }
}

- (void)initButton {
    
    _buttonArray = [NSMutableArray arrayWithCapacity:kButtonCount];
    
    for (int i = 0; i < kButtonCount; i++) {
        CustomToolButton *button = [[CustomToolButton alloc] init];
        button.tag = i;
        
        if (i == _selectedIndex) {
            button.selected = YES;
        }
        [button addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
        
        [self addSubview:button];
        
        [_buttonArray addObject:button];
    }
}

- (void)click:(CustomToolButton *)button {
    for (CustomToolButton *btn in _buttonArray) {
        if (btn.tag == _selectedIndex) {
            btn.selected = NO;
            break;
        }
    }
    
    button.selected = YES;
    _selectedIndex = button.tag;
    
    if (_toolDelegate && [_toolDelegate respondsToSelector:@selector(mosaicToolBar:selectedIndex:)]) {
        [_toolDelegate mosaicToolBar:self selectedIndex:_selectedIndex];
    }
}

@end
