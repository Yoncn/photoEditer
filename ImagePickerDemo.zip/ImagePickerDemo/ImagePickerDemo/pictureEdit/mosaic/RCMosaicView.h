//
//  RCMosaicView.h
//  demo
//
//  Created by yoncn on 2018/2/12.
//  Copyright © 2018年 yoncn. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, RCMosaicWidth) {
    RCMosaicWidth1,
    RCMosaicWidth2,
    RCMosaicWidth3,
    RCMosaicWidth4,
    RCMosaicWidth5,
};

@interface RCMosaicView : UIView

@property (nonatomic, strong) UIImage *image;

//马赛克密度，默认50
@property (nonatomic) NSUInteger level;

//默认RCMosaicWidth3
@property (nonatomic) RCMosaicWidth currentWidth;

- (void)drawPath:(CGPathRef)path;

- (void)draw:(CGPoint)point firstPoint:(BOOL)first;
- (void)drawEnd;

- (void)clearAll;

//能否撤销最后一步
- (BOOL)undoEnabled;

//撤销最后一步
- (void)undo;

@end
