//
//  RCMosaicView.m
//  demo
//
//  Created by yoncn on 2018/2/12.
//  Copyright © 2018年 yoncn. All rights reserved.
//

#import "RCMosaicView.h"

#define kBitsPerComponent (8)
#define kBitsPerPixel (32)
#define kPixelChannelCount (4)

@interface RCMosaicView() {
    CGMutablePathRef _path1, _path2, _path3, _path4, _path5;
    
    CGPoint _prevPoint;
    
    NSMutableArray *_mosaicCache;
    
    NSMutableArray *_points;
}

@property (nonatomic, strong) CALayer *imageLayer;
@property (nonatomic, strong) CAShapeLayer *contentLayer;

@property (nonatomic, strong) CAShapeLayer *layer1;
@property (nonatomic, strong) CAShapeLayer *layer2;
@property (nonatomic, strong) CAShapeLayer *layer3;
@property (nonatomic, strong) CAShapeLayer *layer4;
@property (nonatomic, strong) CAShapeLayer *layer5;

@end

@implementation RCMosaicView

- (void)drawPath:(CGPathRef)path {
    for (CAShapeLayer *layer in self.contentLayer.sublayers) {
        layer.path = NULL;
    }
    
    if (_currentWidth < _contentLayer.sublayers.count) {
        CAShapeLayer *layer = (CAShapeLayer *)_contentLayer.sublayers[_currentWidth];
        layer.path = path;
    }
}

- (void)draw:(CGPoint)point firstPoint:(BOOL)first {
    
    CGMutablePathRef path = [self getPath:_currentWidth];
    
    if (path == NULL) {
        return;
    }
    
    if (first) {
        //加起始点
        CGPathMoveToPoint(path, NULL, point.x, point.y);
        
        _points = [NSMutableArray array];
        //_points加第一个对象（宽度）
        NSNumber *number = [NSNumber numberWithInteger:_currentWidth];
        [_points addObject:number];
    } else {
        CGPathAddQuadCurveToPoint(path, NULL, _prevPoint.x, _prevPoint.y, (point.x + _prevPoint.x) / 2, (point.y + _prevPoint.y) / 2);
    }
    
    //_points第二个对象开始都是点
    NSValue *value = [NSValue valueWithCGPoint:point];
    [_points addObject:value];
    
    _prevPoint = point;
    
    if (_currentWidth < _contentLayer.sublayers.count) {
        CAShapeLayer *layer = (CAShapeLayer *)_contentLayer.sublayers[_currentWidth];
        layer.path = path;
    }
}

- (void)drawEnd {
    if (_points) {
        if (_points.count > 2) {
           [_mosaicCache addObject:_points];
        }
        _points = nil;
    }
}

- (void)clearAll {
    [self clear];
    [_mosaicCache removeAllObjects];
}

- (BOOL)undoEnabled {
    return _mosaicCache.count > 0;
}

- (void)undo {
    if (_mosaicCache.count == 0) {
        return;
    }
    
    [_mosaicCache removeLastObject];
    
    [self clear];
    
    for (NSArray *points in _mosaicCache) {
        //取第一个值（轨迹的宽），再根据宽度取到对应的path
        NSInteger width = [points.firstObject integerValue];
        CGMutablePathRef path = [self getPath:width];
        if (path == NULL) {
            continue;
        }
        
        __block CGPoint fromPoint, toPoint;
        [points enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            if (idx > 0) {
                CGPoint point = [obj CGPointValue];
                if (idx == 1) {
                    fromPoint = point;
                    CGPathMoveToPoint(path, NULL, fromPoint.x, fromPoint.y);
                    //如果只有一个点
                    //                    if (points.count == 2) {
                    //                        CGPathAddQuadCurveToPoint(path, NULL, fromPoint.x, fromPoint.y, fromPoint.x, fromPoint.y);
                    //                    }
                } else {
                    toPoint = point;
                    CGPathAddQuadCurveToPoint(path, NULL, fromPoint.x, fromPoint.y, (toPoint.x + fromPoint.x) / 2, (toPoint.y + fromPoint.y) / 2);
                    fromPoint = toPoint;
                }
            }
        }];
        
        if (width < _contentLayer.sublayers.count) {
            CAShapeLayer *layer = (CAShapeLayer *)_contentLayer.sublayers[width];
            layer.path = path;
        }
    }
    
    
}

-(void)setLevel:(NSUInteger)level {
    if (level == 0) {
        return;
    }
    
    _level = level;
}

- (CALayer *)imageLayer {
    if (!_imageLayer) {
        _imageLayer = [CALayer layer];
    }
    return _imageLayer;
}

- (CAShapeLayer *)contentLayer {
    if (!_contentLayer) {
        _contentLayer = [CAShapeLayer layer];
    }
    return _contentLayer;
}

- (void)dealloc {
    [self clear];
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self initSubViews];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    _imageLayer.frame = self.bounds;
    _contentLayer.frame = self.bounds;
    
    for (CAShapeLayer *layer in self.contentLayer.sublayers) {
        layer.frame = self.bounds;
    }
    
}

- (void)initSubViews {
    
    _level = 50;
    _currentWidth = RCMosaicWidth3;
    
    _mosaicCache = [NSMutableArray array];
    
    [self.layer addSublayer:self.imageLayer];
    [self.layer addSublayer:self.contentLayer];
    
    for (int i = 0; i < 5; i++) {
        CAShapeLayer *layer = [CAShapeLayer layer];
        layer.lineCap = kCALineCapRound;
        layer.lineJoin = kCALineJoinRound;
        layer.strokeColor = [[UIColor blueColor] CGColor];
        layer.fillColor = nil;
        layer.lineWidth = 22 + 4 * i;
        [self.contentLayer addSublayer:layer];
        
    }    
    
    self.imageLayer.mask = self.contentLayer;
}

- (void)setImage:(UIImage *)image
{
    _image = image;

    int value = image.size.width / _level;
    NSLog(@"setup size:%@, value:%d", NSStringFromCGSize(image.size), value);
    
    UIImage *temp = [self transToMosaicImage:image blockLevel:value];
    //    UIImage *temp = [self setup:image];
    self.imageLayer.contents = (id)temp.CGImage;
}

//1. 用苹果滤镜CIFilter 来实现马赛克
- (UIImage *)setup:(UIImage *)image scale:(NSUInteger)scale {
    CIImage *ciImage = [[CIImage alloc] initWithImage:image];
    //生成马赛克
    CIFilter *filter = [CIFilter filterWithName:@"CIPixellate"];
    [filter setValue:ciImage  forKey:kCIInputImageKey];

    //马赛克像素大小
    [filter setValue:@(scale) forKey:kCIInputScaleKey];
    CIImage *outImage = [filter valueForKey:kCIOutputImageKey];
    
    CIContext *context = [CIContext contextWithOptions:nil];
    CGImageRef cgImage = [context createCGImage:outImage fromRect:[outImage extent]];
    UIImage *showImage = [UIImage imageWithCGImage:cgImage];
    CGImageRelease(cgImage);
    
    return showImage;
}

//2. 马赛克算法,level代表一个点转为多少level*level的正方形
- (UIImage *)transToMosaicImage:(UIImage *)orginImage blockLevel:(NSUInteger)level
{
    //获取BitmapData
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    CGImageRef imgRef = orginImage.CGImage;
    CGFloat width = CGImageGetWidth(imgRef);
    CGFloat height = CGImageGetHeight(imgRef);
    CGContextRef context = CGBitmapContextCreate (nil,
                                                  width,
                                                  height,
                                                  kBitsPerComponent,        //每个颜色值8bit
                                                  width*kPixelChannelCount, //每一行的像素点占用的字节数，每个像素点的ARGB四个通道各占8个bit
                                                  colorSpace,
                                                  kCGImageAlphaPremultipliedLast);
    CGContextDrawImage(context, CGRectMake(0, 0, width, height), imgRef);
    unsigned char *bitmapData = CGBitmapContextGetData (context);
    
    //这里把BitmapData进行马赛克转换,就是用一个点的颜色填充一个level*level的正方形
    unsigned char pixel[kPixelChannelCount] = {0};
    NSUInteger index,preIndex;
    for (NSUInteger i = 0; i < height - 1 ; i++) {
        for (NSUInteger j = 0; j < width - 1; j++) {
            index = i * width + j;
            if (i % level == 0) {
                if (j % level == 0) {
                    memcpy(pixel, bitmapData + kPixelChannelCount*index, kPixelChannelCount);
                }else{
                    memcpy(bitmapData + kPixelChannelCount*index, pixel, kPixelChannelCount);
                }
            } else {
                preIndex = (i-1)*width +j;
                memcpy(bitmapData + kPixelChannelCount*index, bitmapData + kPixelChannelCount*preIndex, kPixelChannelCount);
            }
        }
    }
    
    NSInteger dataLength = width*height* kPixelChannelCount;
    CGDataProviderRef provider = CGDataProviderCreateWithData(NULL, bitmapData, dataLength, NULL);
    //创建要输出的图像
    CGImageRef mosaicImageRef = CGImageCreate(width, height,
                                              kBitsPerComponent,
                                              kBitsPerPixel,
                                              width*kPixelChannelCount ,
                                              colorSpace,
                                              kCGBitmapByteOrderDefault,
                                              provider,
                                              NULL, NO,
                                              kCGRenderingIntentDefault);
    CGContextRef outputContext = CGBitmapContextCreate(nil,
                                                       width,
                                                       height,
                                                       kBitsPerComponent,
                                                       width*kPixelChannelCount,
                                                       colorSpace,
                                                       kCGImageAlphaPremultipliedLast);
    CGContextDrawImage(outputContext, CGRectMake(0.0f, 0.0f, width, height), mosaicImageRef);
    CGImageRef resultImageRef = CGBitmapContextCreateImage(outputContext);
    UIImage *resultImage = nil;
    if([UIImage respondsToSelector:@selector(imageWithCGImage:scale:orientation:)]) {
        float scale = [[UIScreen mainScreen] scale];
        resultImage = [UIImage imageWithCGImage:resultImageRef scale:scale orientation:UIImageOrientationUp];
    } else {
        resultImage = [UIImage imageWithCGImage:resultImageRef];
    }
    //释放
    if(resultImageRef){
        CFRelease(resultImageRef);
    }
    if(mosaicImageRef){
        CFRelease(mosaicImageRef);
    }
    if(colorSpace){
        CGColorSpaceRelease(colorSpace);
    }
    if(provider){
        CGDataProviderRelease(provider);
    }
    if(context){
        CGContextRelease(context);
    }
    if(outputContext){
        CGContextRelease(outputContext);
    }
    return resultImage;
    
}

- (CGMutablePathRef)getPath:(RCMosaicWidth)width {
    
    CGMutablePathRef path = NULL;
    
    switch (width) {
        case RCMosaicWidth1:
            if (_path1 == NULL) {
                _path1 = CGPathCreateMutable();
            }
            
            path = _path1;
            break;
        case RCMosaicWidth2:
            if (_path2 == NULL) {
                _path2 = CGPathCreateMutable();
            }
            
            path = _path2;
            break;
        case RCMosaicWidth3:
            if (_path3 == NULL) {
                _path3 = CGPathCreateMutable();
            }
            
            path = _path3;
            break;
        case RCMosaicWidth4:
            if (_path4 == NULL) {
                _path4 = CGPathCreateMutable();
            }
            
            path = _path4;
            break;
        case RCMosaicWidth5:
            if (_path5 == NULL) {
                _path5 = CGPathCreateMutable();
            }
            
            path = _path5;
            break;
            
        default:
            break;
    }
    
    return path;
}

- (void)clear {
    if (_path1) {
        CGPathRelease(_path1);
        _path1 = NULL;
    }
    
    if (_path2) {
        CGPathRelease(_path2);
        _path2 = NULL;
    }
    
    if (_path3) {
        CGPathRelease(_path3);
        _path3 = NULL;
    }
    
    if (_path4) {
        CGPathRelease(_path4);
        _path4 = NULL;
    }
    
    if (_path5) {
        CGPathRelease(_path5);
        _path5 = NULL;
    }
    
    for (CAShapeLayer *layer in self.contentLayer.sublayers) {
        layer.path = NULL;
    }
}

@end
