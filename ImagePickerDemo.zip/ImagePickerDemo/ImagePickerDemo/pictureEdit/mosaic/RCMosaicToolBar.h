//
//  RCMosaicToolBar.h
//  demo
//
//  Created by yoncn on 2018/3/14.
//  Copyright © 2018年 yoncn. All rights reserved.
//

#import <UIKit/UIKit.h>

@class RCMosaicToolBar;

@protocol RCMosaicToolBarDelegate <NSObject>

- (void)mosaicToolBar:(RCMosaicToolBar *)mosaicToolBar selectedIndex:(NSUInteger)selectedIndex;

@end

@interface RCMosaicToolBar : UIView

@property (nonatomic, weak) id<RCMosaicToolBarDelegate> toolDelegate;

@property (nonatomic, readonly) NSUInteger selectedIndex;

@end
