//
//  ButtonExtension.m
//  demo
//
//  Created by yoncn on 2017/7/17.
//  Copyright © 2017年 yoncn. All rights reserved.
//

#import "ButtonExtension.h"

@implementation ButtonExtension

- (BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event {
    CGRect buttonBounds = self.bounds;
    buttonBounds = CGRectInset(buttonBounds, -50, -50);
    return CGRectContainsPoint(buttonBounds, point);
}

@end
